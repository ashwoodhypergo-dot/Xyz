# WakeLock AI — Advanced Offline Smart Alarm for Android (Alarmy-Style)

WakeLock AI is a complete, production-grade, 100% offline Android Smart Alarm application built with **Kotlin**, **Jetpack Compose (Material 3)**, **CameraX**, **Room Database**, **DataStore Preferences**, **AlarmManager (`setAlarmClock`)**, and **On-Device Computer Vision (`LiteRT / TensorFlow Lite` + Multi-Modal Spatial Feature Extraction)**.

---

## 1. Complete Offline Guarantee (Zero Internet Permission)

- **Zero Network Socket Capability**: `android.permission.INTERNET` is explicitly omitted and stripped (`tools:node="remove"`) in `AndroidManifest.xml`. The Android OS kernel prevents the app from ever making network calls.
- **Bundled On-Device AI Asset**: `app/src/main/assets/scene_embedder_v1.tflite` (271 KB) is bundled directly inside the APK (`noCompress += listOf("tflite", "bin")`) and loads on first launch in Airplane Mode without downloading anything.
- **No Accounts, No Cloud, No Analytics**: All alarms, reference photographs, 128-D neural embeddings, spatial descriptors, and mission logs live strictly in local private storage (`context.filesDir/reference_photos/` and `Room` SQLite database).

---

## 2. Photo Mission Architecture & Live CameraX Enforcement

### A. Setting the Reference Photograph (Alarm Creation / Editing Only)
1. During alarm creation/editing (`AlarmEditorScreen.kt`), selecting **Photo Mission** opens the system Photo Picker (`ActivityResultContracts.PickVisualMedia` with `GetContent` fallback).
2. `ReferencePhotoStorage.kt` decodes the image, normalizes EXIF orientation, scales to a max edge of 1024px, saves the JPEG in private sandbox storage (`filesDir/reference_photos/`), and records its **SHA-256 cryptographic digest**.
3. `SceneFeatureExtractor.kt` immediately extracts a `SceneFingerprint` containing:
   - **128-D L2-Normalized Neural Convolutional Scene Embedding** (using `assets/scene_embedder_v1.tflite` — supporting both a standard `org.tensorflow.lite.Interpreter` graph or the bundled 32-filter 5x5x3 Gabor + Opponent-Color Convolutional Pyramid with a 512→128 orthogonal projection matrix).
   - **192-D 4x4 Spatial Grid Chromaticity & Opponent-Color Histogram** with Gray-World white-balance normalization for lighting invariance.
   - **128-D 4x4 Spatial Oriented Gradient (HOG / Sobel 8-bin)** structural descriptor.
   - **Up to 64 ORB/FAST-style Local Corner Keypoints + 64-bit Binary BRIEF Descriptors** and normalized `(x, y)` coordinates.
   - **256-D (16x16) Multi-Scale Luminance Structural Grid** for shift-tolerant SSIM matching.

### B. Live Camera Verification During Alarm Ringing (`AlarmRingingActivity.kt`)
- When the alarm triggers, `AlarmService` starts as a `specialUse|mediaPlayback` Foreground Service holding a CPU `WakeLock`, playing the selected alarm tone with progressive volume ramp-up on `STREAM_ALARM`, and launching `AlarmRingingActivity` over the lock screen (`setShowWhenLocked(true)`, `setTurnScreenOn(true)`).
- **Strict Anti-Bypass & Live Capture Rules**:
  - **No Gallery Access During Ringing**: `AlarmRingingActivity` has **zero** gallery pickers, file choosers, or URI inputs. It binds exclusively to `CameraX` (`PreviewView` + `ImageCapture.takePicture`) to capture a fresh in-memory `ImageProxy` frame directly from the physical camera sensor.
  - **Reference Recycling Rejection**: `PhotoSimilarityEngine.verify()` compares SHA-256 hashes and rejects any frame identical to the stored reference file (`overallScore = 0`).
  - **Covered Lens / Dark Frame Rejection**: Rejects pitch-black or zero-contrast frames and prompts the user to use the built-in camera torch button.
  - **Reference Ghost Overlay**: Includes a toggleable 28%-opacity ghost overlay of the reference photo over the live CameraX viewfinder so groggy users can align their camera angle in seconds.

### C. Multi-Modal Scene Similarity Scoring & Calibrated Thresholds
`PhotoSimilarityEngine.kt` computes a composite similarity score (`0..100`) combining:
- **32%** Neural Convolutional Embedding Cosine Similarity
- **33%** Shift-Tolerant Spatial Structure (`4x4` HOG + `±2` cell translation-invariant `16x16` SSIM)
- **17%** White-Balanced Spatial Color Layout Similarity
- **18%** ORB/BRIEF Keypoint Hamming + Spatial Coherence Matching
- **Structural Concordance Gate**: Prevents an unrelated object that happens to share wall colors from passing.
- **Difficulty Presets + Custom Slider**:
  - `Easy`: **62%** threshold (±25° angle tolerance, wide lighting shift)
  - `Normal (Recommended)`: **74%** threshold (±15° angle tolerance, day/night lighting shift)
  - `Hard (Strict)`: **84%** threshold (±8° angle tolerance, close framing alignment)
  - `Custom`: User-adjustable slider from **50% to 95%**

---

## 3. Extra Value-Add Features Included

1. **Ghost Alignment Overlay & Torch Control in Live CameraX Viewfinder**: Toggle a semi-transparent overlay of your reference photo and toggle the LED flashlight directly inside the live Photo Mission screen.
2. **Interactive On-Device AI Vision Lab (`SettingsAndDiagnosticsScreen.kt`)**: Test the actual on-device feature extractor and similarity engine anytime against positive variations (angle shift, warm morning lighting) and negative scenes (different washbasin, kitchen refrigerator) with a visual breakdown of all 4 sub-scores.
3. **5-Minute Post-Alarm Wake-Up Check**: Optional secondary verification 5 minutes after alarm dismissal to make sure you didn't fall back asleep.
4. **Away-From-Home Emergency Fallback**: Optional setting allowing you to solve 5 hard mental arithmetic equations if you are traveling or locked out of the target room after 3 failed photo attempts.
5. **90-Minute REM Sleep Cycle Calculator & 1-Tap Quick Power Naps**: Home dashboard displays optimal 4, 5, and 6 sleep-cycle wake times and 1-tap `+15m`, `+25m`, `+45m`, and `+90m` power nap buttons.
6. **Hardware Volume Key Lock & Flashlight Strobe**: Intercepts physical volume down/mute keys during ringing and optionally strobes the camera LED.

---

## 4. How to Build and Run the APK in Android Studio

### Prerequisites
- **Android Studio Ladybug (2024.2.1)** or newer
- **JDK 17** (bundled with Android Studio)
- **Android SDK 35** (minSdk 26 / Android 8.0+)

### Build Steps
1. Unzip `WakeLockAI_SmartAlarm_AndroidProject.zip` and open the `WakeLockAI_SmartAlarm` folder in **Android Studio**.
2. Let Gradle sync dependencies.
3. Connect a physical Android device (recommended for testing live CameraX Photo Mission and lock-screen wake-up) or start an emulator with a virtual camera scene configured.
4. Build and install the debug APK:
   - Via Android Studio: Click **Run 'app'** (`Shift + F10`), or **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   - Via Command Line:
     ```bash
     ./gradlew assembleDebug
     ```
   - The compiled APK will be generated at:
     `app/build/outputs/apk/debug/app-debug.apk`
5. Run the unit test suite:
   ```bash
   ./gradlew testDebugUnitTest
   ```
