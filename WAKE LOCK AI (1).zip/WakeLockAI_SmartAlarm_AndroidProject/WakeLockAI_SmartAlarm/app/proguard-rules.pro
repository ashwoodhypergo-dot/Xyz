# Keep LiteRT / TensorFlow Lite Interpreter classes
-keep class org.tensorflow.lite.** { *; }
-keep class com.google.ai.edge.litert.** { *; }

# Keep Room entities and DAOs
-keep class com.wakelockai.smartalarm.data.local.** { *; }
-keep class com.wakelockai.smartalarm.domain.model.** { *; }

# Keep Kotlinx Serialization generated serializers
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.wakelockai.smartalarm.**$$serializer { *; }
