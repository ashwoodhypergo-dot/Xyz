package com.wakelockai.smartalarm.alarm

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.wakelockai.smartalarm.MainActivity
import com.wakelockai.smartalarm.R
import com.wakelockai.smartalarm.WakeLockApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Receives exact alarm triggers and Wake-Up Check triggers from Android's AlarmManager.
 */
class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val alarmId = intent.getLongExtra(EXTRA_ALARM_ID, -1L)
        if (alarmId == -1L) return

        when (action) {
            ACTION_TRIGGER_ALARM -> {
                // Immediately start the unstoppable foreground AlarmService
                AlarmService.startAlarm(context, alarmId)

                // If the alarm is a repeating alarm, pre-schedule the next occurrence so even if the phone
                // reboots while ringing, the next cycle is already persisted
                val pendingResult = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val app = context.applicationContext as? WakeLockApplication
                        val repo = app?.alarmRepository
                        val scheduler = app?.alarmScheduler
                        val alarm = repo?.getAlarmById(alarmId)
                        if (alarm != null && alarm.repeatDays.isNotEmpty() && alarm.snoozedUntilMillis == null) {
                            val nextMillis = scheduler?.scheduleAlarm(alarm) ?: 0L
                            repo.updateAlarm(alarm.copy(nextTriggerTimeMillis = nextMillis))
                        }
                    } finally {
                        pendingResult.finish()
                    }
                }
            }

            ACTION_WAKE_UP_CHECK -> {
                val label = intent.getStringExtra(EXTRA_ALARM_LABEL) ?: "Wake-Up Check"
                showWakeUpCheckNotification(context, alarmId, label)
            }
        }
    }

    private fun showWakeUpCheckNotification(context: Context, alarmId: Long, label: String) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_ALARM_ID, alarmId)
        }
        val pi = PendingIntent.getActivity(
            context,
            alarmId.toInt() + 60_000,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, WakeLockApplication.CHANNEL_WAKEUP_CHECK)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Still Awake? ($label)")
            .setContentText("5-minute post-mission Wake-Up Check completed. Have a productive day!")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()

        nm.notify(alarmId.toInt() + 70_000, notification)
    }

    companion object {
        const val ACTION_TRIGGER_ALARM = "com.wakelockai.smartalarm.ACTION_TRIGGER_ALARM"
        const val ACTION_SNOOZE_ALARM = "com.wakelockai.smartalarm.ACTION_SNOOZE_ALARM"
        const val ACTION_WAKE_UP_CHECK = "com.wakelockai.smartalarm.ACTION_WAKE_UP_CHECK"
        const val EXTRA_ALARM_ID = "extra_alarm_id"
        const val EXTRA_ALARM_LABEL = "extra_alarm_label"
        const val EXTRA_IS_SNOOZE = "extra_is_snooze"
    }
}
