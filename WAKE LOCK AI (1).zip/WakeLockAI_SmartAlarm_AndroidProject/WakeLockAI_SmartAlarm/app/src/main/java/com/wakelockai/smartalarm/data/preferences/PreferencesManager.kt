package com.wakelockai.smartalarm.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.wakelockai.smartalarm.domain.model.MatchingDifficulty
import com.wakelockai.smartalarm.domain.model.ThemeMode
import com.wakelockai.smartalarm.domain.model.VibrationPattern
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "wakelock_user_settings")

data class UserSettings(
    val use24HourFormat: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.DARK_AMOLED,
    val defaultRingtoneUri: String = "DEFAULT_ALARM",
    val defaultRingtoneTitle: String = "System Default Alarm",
    val defaultAlarmVolume: Float = 0.85f,
    val defaultVibrationEnabled: Boolean = true,
    val defaultVibrationPattern: VibrationPattern = VibrationPattern.HEARTBEAT,
    val defaultSnoozeDurationMinutes: Int = 5,
    val defaultMaxSnoozes: Int = 3,
    val defaultMatchingDifficulty: MatchingDifficulty = MatchingDifficulty.NORMAL,
    val defaultGhostOverlayEnabled: Boolean = true,
    val antiSpoofScreenCheckEnabled: Boolean = true,
    val lockVolumeButtonsDuringAlarm: Boolean = true
)

class PreferencesManager(private val context: Context) {

    private object Keys {
        val USE_24_HOUR = booleanPreferencesKey("use_24_hour_format")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DEFAULT_RINGTONE_URI = stringPreferencesKey("default_ringtone_uri")
        val DEFAULT_RINGTONE_TITLE = stringPreferencesKey("default_ringtone_title")
        val DEFAULT_VOLUME = floatPreferencesKey("default_alarm_volume")
        val DEFAULT_VIBRATION = booleanPreferencesKey("default_vibration_enabled")
        val DEFAULT_VIBRATION_PATTERN = stringPreferencesKey("default_vibration_pattern")
        val DEFAULT_SNOOZE_MINS = intPreferencesKey("default_snooze_minutes")
        val DEFAULT_MAX_SNOOZES = intPreferencesKey("default_max_snoozes")
        val DEFAULT_DIFFICULTY = stringPreferencesKey("default_matching_difficulty")
        val DEFAULT_GHOST_OVERLAY = booleanPreferencesKey("default_ghost_overlay")
        val ANTI_SPOOF_SCREEN = booleanPreferencesKey("anti_spoof_screen_check")
        val LOCK_VOLUME_BUTTONS = booleanPreferencesKey("lock_volume_buttons")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        UserSettings(
            use24HourFormat = prefs[Keys.USE_24_HOUR] ?: false,
            themeMode = runCatching {
                ThemeMode.valueOf(prefs[Keys.THEME_MODE] ?: ThemeMode.DARK_AMOLED.name)
            }.getOrDefault(ThemeMode.DARK_AMOLED),
            defaultRingtoneUri = prefs[Keys.DEFAULT_RINGTONE_URI] ?: "DEFAULT_ALARM",
            defaultRingtoneTitle = prefs[Keys.DEFAULT_RINGTONE_TITLE] ?: "System Default Alarm",
            defaultAlarmVolume = prefs[Keys.DEFAULT_VOLUME] ?: 0.85f,
            defaultVibrationEnabled = prefs[Keys.DEFAULT_VIBRATION] ?: true,
            defaultVibrationPattern = runCatching {
                VibrationPattern.valueOf(prefs[Keys.DEFAULT_VIBRATION_PATTERN] ?: VibrationPattern.HEARTBEAT.name)
            }.getOrDefault(VibrationPattern.HEARTBEAT),
            defaultSnoozeDurationMinutes = prefs[Keys.DEFAULT_SNOOZE_MINS] ?: 5,
            defaultMaxSnoozes = prefs[Keys.DEFAULT_MAX_SNOOZES] ?: 3,
            defaultMatchingDifficulty = runCatching {
                MatchingDifficulty.valueOf(prefs[Keys.DEFAULT_DIFFICULTY] ?: MatchingDifficulty.NORMAL.name)
            }.getOrDefault(MatchingDifficulty.NORMAL),
            defaultGhostOverlayEnabled = prefs[Keys.DEFAULT_GHOST_OVERLAY] ?: true,
            antiSpoofScreenCheckEnabled = prefs[Keys.ANTI_SPOOF_SCREEN] ?: true,
            lockVolumeButtonsDuringAlarm = prefs[Keys.LOCK_VOLUME_BUTTONS] ?: true
        )
    }

    suspend fun setUse24HourFormat(enabled: Boolean) {
        context.dataStore.edit { it[Keys.USE_24_HOUR] = enabled }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setDefaultRingtone(uri: String, title: String) {
        context.dataStore.edit {
            it[Keys.DEFAULT_RINGTONE_URI] = uri
            it[Keys.DEFAULT_RINGTONE_TITLE] = title
        }
    }

    suspend fun setDefaultVolume(volume: Float) {
        context.dataStore.edit { it[Keys.DEFAULT_VOLUME] = volume.coerceIn(0.1f, 1.0f) }
    }

    suspend fun setDefaultVibrationEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DEFAULT_VIBRATION] = enabled }
    }

    suspend fun setDefaultVibrationPattern(pattern: VibrationPattern) {
        context.dataStore.edit { it[Keys.DEFAULT_VIBRATION_PATTERN] = pattern.name }
    }

    suspend fun setDefaultSnoozeMinutes(minutes: Int) {
        context.dataStore.edit { it[Keys.DEFAULT_SNOOZE_MINS] = minutes }
    }

    suspend fun setDefaultMaxSnoozes(maxSnoozes: Int) {
        context.dataStore.edit { it[Keys.DEFAULT_MAX_SNOOZES] = maxSnoozes }
    }

    suspend fun setDefaultDifficulty(difficulty: MatchingDifficulty) {
        context.dataStore.edit { it[Keys.DEFAULT_DIFFICULTY] = difficulty.name }
    }

    suspend fun setAntiSpoofScreenCheck(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ANTI_SPOOF_SCREEN] = enabled }
    }

    suspend fun setLockVolumeButtons(enabled: Boolean) {
        context.dataStore.edit { it[Keys.LOCK_VOLUME_BUTTONS] = enabled }
    }

    suspend fun resetAllPreferences() {
        context.dataStore.edit { it.clear() }
    }
}
