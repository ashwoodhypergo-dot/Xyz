package com.wakelockai.smartalarm.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.wakelockai.smartalarm.data.local.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Restores and recalculates all enabled alarms automatically after:
 * - Device reboot (BOOT_COMPLETED, LOCKED_BOOT_COMPLETED, QUICKBOOT_POWERON)
 * - App update (MY_PACKAGE_REPLACED)
 * - Manual clock adjustment (TIME_SET)
 * - Timezone change (TIMEZONE_CHANGED)
 * - Exact alarm permission grant (SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED)
 */
class BootAndTimeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val validActions = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_SET,
            Intent.ACTION_TIMEZONE_CHANGED,
            "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED"
        )
        if (action !in validActions) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getInstance(context)
                val dao = db.alarmDao()
                val scheduler = AlarmScheduler(context)
                val enabledAlarms = dao.getEnabledAlarmsOnce()

                for (alarm in enabledAlarms) {
                    val nextTrigger = scheduler.scheduleAlarm(alarm)
                    dao.updateAlarm(alarm.copy(nextTriggerTimeMillis = nextTrigger))
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
