package com.wakelockai.smartalarm.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.wakelockai.smartalarm.domain.model.MatchingDifficulty
import com.wakelockai.smartalarm.domain.model.MissionType
import com.wakelockai.smartalarm.domain.model.VibrationPattern

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val hour: Int,                              // 0..23
    val minute: Int,                            // 0..59
    val label: String = "Morning Wake Up",
    val isEnabled: Boolean = true,
    val repeatDays: Set<Int> = emptySet(),      // 1 = Monday .. 7 = Sunday (ISO-8601); empty = one-time alarm
    val ringtoneUri: String = "DEFAULT_ALARM",
    val ringtoneTitle: String = "System Default Alarm",
    val alarmVolume: Float = 0.85f,             // 0.1f .. 1.0f
    val progressiveVolumeRampSeconds: Int = 20, // 0 = immediate, 20 = 20s gentle ramp to full volume
    val vibrationEnabled: Boolean = true,
    val vibrationPattern: VibrationPattern = VibrationPattern.HEARTBEAT,
    val snoozeEnabled: Boolean = true,
    val snoozeDurationMinutes: Int = 5,         // 1, 3, 5, 10, 15, 30
    val maxSnoozeCount: Int = 3,                // 0..10
    val currentSnoozeCount: Int = 0,
    val snoozedUntilMillis: Long? = null,
    val missionType: MissionType = MissionType.PHOTO,
    val referencePhotoPath: String? = null,
    val referencePhotoSha256: String? = null,
    val referenceFingerprintJson: String? = null,
    val matchingDifficulty: MatchingDifficulty = MatchingDifficulty.NORMAL,
    val customSimilarityThreshold: Float = 74.0f,
    val mathDifficultyLevel: Int = 2,           // 1 = Easy, 2 = Medium, 3 = Hard
    val mathProblemCount: Int = 3,
    val shakeTargetCount: Int = 30,
    val allowEmergencyMathFallback: Boolean = true, // Allows solving 5 hard math problems if user is away from home
    val wakeUpCheckEnabled: Boolean = false,    // Re-verifies user is awake 5 minutes after dismissal
    val flashlightStrobeEnabled: Boolean = false,
    val nextTriggerTimeMillis: Long = 0L,
    val createdAtMillis: Long = System.currentTimeMillis()
)
