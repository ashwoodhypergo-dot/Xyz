package com.wakelockai.smartalarm.vision

import com.wakelockai.smartalarm.domain.model.MatchingDifficulty
import com.wakelockai.smartalarm.domain.model.SceneFingerprint
import com.wakelockai.smartalarm.domain.model.VerificationBreakdown
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Multi-Modal Scene Similarity & Liveness Verification Engine.
 *
 * Evaluates whether a live CameraX photograph captures the SAME PARTICULAR VISUAL SCENE
 * as the stored reference SceneFingerprint.
 *
 * Scoring Weights & Shift-Tolerance:
 * 1. Neural Convolutional Scene Embedding Cosine Similarity (32% weight)
 *    - Evaluates multi-scale Gabor + Opponent-Color filter activations across the scene.
 * 2. Shift-Tolerant Spatial Edge & Structural Similarity (33% weight)
 *    - Combines 4x4 Spatial Oriented Gradient (HOG) cosine similarity + Multi-offset 16x16 SSIM
 *      (searches ±2 grid cells horizontally and vertically so minor framing/angle/distance variations
 *      still align with the reference scene structure).
 * 3. Illumination-Normalized Spatial Chromaticity & Color Layout (17% weight)
 *    - Compares 4x4 white-balanced color histograms with translation tolerance, rejecting scenes with
 *      completely different backgrounds while tolerating warm/cool morning light changes.
 * 4. ORB/BRIEF Local Keypoint Geometric Matching (18% weight)
 *    - Matches 64-bit BRIEF binary descriptors using Hamming distance and verifies spatial neighborhood
 *      consistency (ensuring matched keypoints appear in a coherent relative geometric layout).
 *
 * Strict Anti-Spoofing & Live Capture Integrity:
 * - Rejects exact duplicate SHA-256 hashes (guarantees the reference image itself can never be fed back).
 * - Rejects completely dark/covered camera frames or uniform blank walls when the reference has structure.
 */
class PhotoSimilarityEngine {

    fun verify(
        reference: SceneFingerprint,
        liveCapture: SceneFingerprint,
        difficulty: MatchingDifficulty,
        customThreshold: Float = difficulty.defaultThreshold,
        antiSpoofEnabled: Boolean = true
    ): VerificationBreakdown {
        val targetThreshold = when (difficulty) {
            MatchingDifficulty.CUSTOM -> customThreshold.coerceIn(50.0f, 95.0f)
            else -> difficulty.defaultThreshold
        }

        // STRICT RULE 1: Never treat the reference photograph itself as a successful mission photograph
        if (reference.sha256Hex.isNotBlank() && reference.sha256Hex == liveCapture.sha256Hex) {
            return VerificationBreakdown(
                overallScore = 0f,
                requiredThreshold = targetThreshold,
                isMatched = false,
                neuralEmbeddingSimilarity = 0f,
                spatialStructureSimilarity = 0f,
                colorLayoutSimilarity = 0f,
                keypointGeometrySimilarity = 0f,
                livenessPassed = false,
                failureReason = "Identical reference file hash detected. A fresh live camera capture is required.",
                userFeedbackMessage = "Photograph not matched. Please capture a fresh live photo.",
                coachingTip = "Point the live camera directly at your target object."
            )
        }

        // STRICT RULE 2: Check for covered lens / pitch-black frame or extreme overexposure
        if (liveCapture.meanLuminance < 0.03f || liveCapture.contrastStd < 0.012f) {
            return VerificationBreakdown(
                overallScore = 5.0f,
                requiredThreshold = targetThreshold,
                isMatched = false,
                neuralEmbeddingSimilarity = 0f,
                spatialStructureSimilarity = 0f,
                colorLayoutSimilarity = 0f,
                keypointGeometrySimilarity = 0f,
                livenessPassed = false,
                failureReason = "Camera image is too dark or lens is covered.",
                userFeedbackMessage = "Photograph not matched. Image is too dark or blurry.",
                coachingTip = "Turn on a light or use the flashlight button on screen so the scene is visible."
            )
        }

        // 1. Neural Convolutional Embedding Cosine Similarity (with shift-tolerant pooling)
        val rawNeuralCosine = cosineSimilarity(reference.neuralEmbedding, liveCapture.neuralEmbedding)
        val neuralScore = calibrateCosineToScore(rawNeuralCosine, floor = 0.20f, ceiling = 0.94f)

        // 2. Spatial Edge Orientation (HOG) + Shift-Tolerant 16x16 Structural SSIM
        val hogCosine = shiftTolerantGridCosine(
            refVec = reference.spatialEdgeOrientation,
            liveVec = liveCapture.spatialEdgeOrientation,
            binsPerCell = 8
        )
        val hogScore = calibrateCosineToScore(hogCosine, floor = 0.25f, ceiling = 0.93f)
        val ssimScore = computeShiftTolerantSsimScore(
            refGrid = reference.structuralGridLuminance,
            liveGrid = liveCapture.structuralGridLuminance
        )
        val spatialStructureScore = (0.58f * hogScore + 0.42f * ssimScore).coerceIn(0f, 100f)

        // 3. Illumination-Normalized Spatial Color Layout Similarity
        val colorCosine = shiftTolerantGridCosine(
            refVec = reference.spatialColorHistogram,
            liveVec = liveCapture.spatialColorHistogram,
            binsPerCell = 12
        )
        val colorScore = calibrateCosineToScore(colorCosine, floor = 0.22f, ceiling = 0.94f)

        // 4. ORB/BRIEF Keypoint Descriptor + Spatial Coherence Score
        val keypointScore = computeKeypointMatchScore(reference, liveCapture)

        // 5. Edge density structural sanity penalty (prevents a blank wall from matching a detailed desk/washbasin)
        val edgeDiff = abs(reference.edgeDensity - liveCapture.edgeDensity)
        val edgePenalty = if (edgeDiff > 0.28f) (edgeDiff - 0.28f) * 35.0f else 0.0f

        // Weighted Composite Similarity Score (0..100)
        val rawComposite = (
            0.32f * neuralScore +
                0.33f * spatialStructureScore +
                0.17f * colorScore +
                0.18f * keypointScore
            ) - edgePenalty

        // Apply structural concordance gate: if spatial structure AND neural embedding are both very low,
        // cap the score so a random object with similar wall color never accidentally passes.
        val gatedScore = if (spatialStructureScore < 38.0f && neuralScore < 42.0f) {
            min(rawComposite, 45.0f)
        } else {
            rawComposite
        }.coerceIn(0.0f, 100.0f)

        val isMatched = gatedScore >= targetThreshold

        val coachingTip = when {
            isMatched -> "Scene verified! Great job waking up."
            spatialStructureScore < 50f -> "Try matching the original camera angle and distance more closely."
            keypointScore < 45f -> "Hold the phone steady so distinctive edges and corners are sharp."
            colorScore < 45f -> "Make sure the background around the object matches your saved reference."
            else -> "Almost there (${gatedScore.toInt()}% vs ${targetThreshold.toInt()}% needed). Adjust framing slightly."
        }

        val feedbackMessage = if (isMatched) {
            "Photograph matched."
        } else {
            "Photograph not matched. Please try again."
        }

        return VerificationBreakdown(
            overallScore = gatedScore,
            requiredThreshold = targetThreshold,
            isMatched = isMatched,
            neuralEmbeddingSimilarity = neuralScore,
            spatialStructureSimilarity = spatialStructureScore,
            colorLayoutSimilarity = colorScore,
            keypointGeometrySimilarity = keypointScore,
            livenessPassed = true,
            failureReason = if (isMatched) null else coachingTip,
            userFeedbackMessage = feedbackMessage,
            coachingTip = coachingTip
        )
    }

    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        val n = min(a.size, b.size)
        if (n == 0) return 0f
        var dot = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in 0 until n) {
            dot += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        val denom = sqrt(normA * normB)
        return if (denom > 1e-6f) (dot / denom).coerceIn(-1f, 1f) else 0f
    }

    /**
     * Evaluates cosine similarity across a 4x4 spatial grid while allowing ±1 cell shift
     * (up/down/left/right) so slight camera framing or angle offsets still score accurately.
     */
    private fun shiftTolerantGridCosine(
        refVec: FloatArray,
        liveVec: FloatArray,
        binsPerCell: Int
    ): Float {
        val directCosine = cosineSimilarity(refVec, liveVec)
        if (refVec.size < 16 * binsPerCell || liveVec.size < 16 * binsPerCell) {
            return directCosine
        }

        var bestShifted = directCosine
        for (dy in -1..1) {
            for (dx in -1..1) {
                if (dx == 0 && dy == 0) continue
                var dot = 0.0f
                var normA = 0.0f
                var normB = 0.0f
                for (cy in 0 until 4) {
                    val ly = cy + dy
                    if (ly !in 0..3) continue
                    for (cx in 0 until 4) {
                        val lx = cx + dx
                        if (lx !in 0..3) continue
                        val refBase = (cy * 4 + cx) * binsPerCell
                        val liveBase = (ly * 4 + lx) * binsPerCell
                        for (b in 0 until binsPerCell) {
                            val rv = refVec[refBase + b]
                            val lv = liveVec[liveBase + b]
                            dot += rv * lv
                            normA += rv * rv
                            normB += lv * lv
                        }
                    }
                }
                val denom = sqrt(normA * normB)
                if (denom > 1e-6f) {
                    // Slight 4% discount for shifted alignment so centered framing is preferred
                    val shiftedCos = (dot / denom) * 0.96f
                    if (shiftedCos > bestShifted) {
                        bestShifted = shiftedCos
                    }
                }
            }
        }
        return bestShifted.coerceIn(0f, 1f)
    }

    /**
     * Computes Structural Similarity (SSIM) on the 16x16 normalized luminance map across
     * translations dx, dy in -2..2 (tolerating ±12.5% framing shift and camera tilt).
     */
    private fun computeShiftTolerantSsimScore(
        refGrid: FloatArray,
        liveGrid: FloatArray
    ): Float {
        if (refGrid.size < 256 || liveGrid.size < 256) return 50f
        var bestSsim = -1.0f
        val c1 = 0.01f
        val c2 = 0.03f

        for (dy in -2..2) {
            for (dx in -2..2) {
                var sumRef = 0f
                var sumLive = 0f
                var count = 0
                for (y in 0 until 16) {
                    val ly = y + dy
                    if (ly !in 0..15) continue
                    for (x in 0 until 16) {
                        val lx = x + dx
                        if (lx !in 0..15) continue
                        sumRef += refGrid[y * 16 + x]
                        sumLive += liveGrid[ly * 16 + lx]
                        count++
                    }
                }
                if (count < 100) continue
                val meanR = sumRef / count
                val meanL = sumLive / count

                var varR = 0f
                var varL = 0f
                var cov = 0f
                for (y in 0 until 16) {
                    val ly = y + dy
                    if (ly !in 0..15) continue
                    for (x in 0 until 16) {
                        val lx = x + dx
                        if (lx !in 0..15) continue
                        val dr = refGrid[y * 16 + x] - meanR
                        val dl = liveGrid[ly * 16 + lx] - meanL
                        varR += dr * dr
                        varL += dl * dl
                        cov += dr * dl
                    }
                }
                varR /= count
                varL /= count
                cov /= count

                val numerator = (2f * meanR * meanL + c1) * (2f * cov + c2)
                val denominator = (meanR * meanR + meanL * meanL + c1) * (varR + varL + c2)
                val ssim = if (denominator > 1e-6f) numerator / denominator else 0f
                val shiftDiscount = 1.0f - 0.015f * (abs(dx) + abs(dy))
                val weighted = ssim * shiftDiscount
                if (weighted > bestSsim) {
                    bestSsim = weighted
                }
            }
        }
        return ((bestSsim.coerceIn(0f, 1f)) * 100f).coerceIn(0f, 100f)
    }

    /**
     * Matches 64-bit BRIEF binary descriptors between reference and live keypoints,
     * requiring both descriptor similarity (Hamming distance <= 20 bits out of 64)
     * and spatial proximity (within 28% of normalized canvas radius).
     */
    private fun computeKeypointMatchScore(
        ref: SceneFingerprint,
        live: SceneFingerprint
    ): Float {
        val refCount = ref.keypointDescriptors.size
        val liveCount = live.keypointDescriptors.size
        if (refCount == 0 || liveCount == 0) return 50.0f

        var geometricallyConsistentMatches = 0f
        for (i in 0 until refCount) {
            val rx = ref.keypointCoords[i * 2]
            val ry = ref.keypointCoords[i * 2 + 1]
            val rDesc = ref.keypointDescriptors[i]

            var bestHamming = 64
            var bestSpatialDist = 1.0f

            for (j in 0 until liveCount) {
                val lx = live.keypointCoords[j * 2]
                val ly = live.keypointCoords[j * 2 + 1]
                val distSq = (rx - lx) * (rx - lx) + (ry - ly) * (ry - ly)
                // Allow up to 0.28 normalized translation (angle/distance change)
                if (distSq > 0.08f) continue

                val hamming = java.lang.Long.bitCount(rDesc xor live.keypointDescriptors[j])
                if (hamming < bestHamming) {
                    bestHamming = hamming
                    bestSpatialDist = sqrt(distSq)
                }
            }

            if (bestHamming <= 22) {
                val bitQuality = (1.0f - (bestHamming / 32.0f)).coerceIn(0.2f, 1.0f)
                val spatialQuality = (1.0f - bestSpatialDist * 1.5f).coerceIn(0.4f, 1.0f)
                geometricallyConsistentMatches += bitQuality * spatialQuality
            }
        }

        val matchRatio = geometricallyConsistentMatches / (refCount.toFloat() * 0.52f)
        return (matchRatio * 100.0f).coerceIn(0.0f, 100.0f)
    }

    private fun calibrateCosineToScore(cosine: Float, floor: Float, ceiling: Float): Float {
        if (cosine <= floor) return ((cosine / floor.coerceAtLeast(0.01f)) * 20f).coerceIn(0f, 20f)
        if (cosine >= ceiling) return 100f
        val norm = (cosine - floor) / (ceiling - floor)
        return (20f + norm * 80f).coerceIn(0f, 100f)
    }
}
