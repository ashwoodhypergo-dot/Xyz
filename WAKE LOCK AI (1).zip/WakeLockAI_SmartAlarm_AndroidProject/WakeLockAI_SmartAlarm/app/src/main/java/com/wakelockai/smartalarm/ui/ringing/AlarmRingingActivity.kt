package com.wakelockai.smartalarm.ui.ringing

import android.Manifest
import android.app.ActivityManager
import android.app.KeyguardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraControl
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.wakelockai.smartalarm.WakeLockApplication
import com.wakelockai.smartalarm.alarm.AlarmReceiver
import com.wakelockai.smartalarm.alarm.AlarmService
import com.wakelockai.smartalarm.alarm.AlarmTimeCalculator
import com.wakelockai.smartalarm.data.local.AlarmEntity
import com.wakelockai.smartalarm.data.local.MissionLogEntity
import com.wakelockai.smartalarm.domain.model.MissionType
import com.wakelockai.smartalarm.domain.model.ThemeMode
import com.wakelockai.smartalarm.domain.model.VerificationBreakdown
import com.wakelockai.smartalarm.domain.model.VerificationStage
import com.wakelockai.smartalarm.ui.theme.WakeLockAITheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Full-Screen Lock-Screen Breakthrough Alarm Activity.
 *
 * STRICT ANTI-BYPASS & LIVE CAPTURE RULES:
 * 1. Blocks system Back button / back gesture via OnBackPressedDispatcher.
 * 2. Intercepts hardware Volume Down / Mute keys so the user cannot silence the alarm via buttons.
 * 3. Turns on the screen and shows over the keyguard lock screen (`setShowWhenLocked(true)`, `setTurnScreenOn(true)`).
 * 4. During Photo Mission verification, ONLY live CameraX frames (`ImageCapture.takePicture`) are accepted.
 *    There is ZERO gallery picker, ZERO file import, and ZERO URI input on this screen.
 */
class AlarmRingingActivity : ComponentActivity() {

    private var activeMissionCompleted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureLockScreenBreakthrough()

        // Block Back Button / Gesture until mission is verified
        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    // Intentionally blocked while alarm is active
                }
            }
        )

        val alarmIdFromIntent = intent?.getLongExtra(AlarmReceiver.EXTRA_ALARM_ID, -1L) ?: -1L
        val app = application as WakeLockApplication

        setContent {
            WakeLockAITheme(themeMode = ThemeMode.DARK_AMOLED) {
                val activeServiceAlarm by AlarmService.activeAlarmState.collectAsState()
                var loadedAlarm by remember { mutableStateOf<AlarmEntity?>(null) }

                LaunchedEffect(alarmIdFromIntent, activeServiceAlarm) {
                    loadedAlarm = activeServiceAlarm
                        ?: if (alarmIdFromIntent != -1L) app.alarmRepository.getAlarmById(alarmIdFromIntent) else null
                }

                val currentAlarm = loadedAlarm
                if (currentAlarm != null) {
                    AlarmRingingRootScreen(
                        alarm = currentAlarm,
                        app = app,
                        onSnoozeTriggered = { snoozedAlarm ->
                            handleSnooze(app, snoozedAlarm)
                        },
                        onMissionCompleted = { completedAlarm, attempts, bestScore, usedFallback ->
                            handleMissionSuccess(app, completedAlarm, attempts, bestScore, usedFallback)
                        }
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Intercept Volume Up / Volume Down / Mute / Camera keys so hardware buttons cannot silence the alarm
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE ||
            keyCode == KeyEvent.KEYCODE_MUTE
        ) {
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onPause() {
        super.onPause()
        // If the user swipes to Recent Apps or presses Home without finishing the mission,
        // bring the task back to front while the Foreground Service continues ringing.
        if (!activeMissionCompleted && !isFinishing) {
            runCatching {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                am?.moveTaskToFront(taskId, ActivityManager.MOVE_TASK_WITH_HOME)
            }
        }
    }

    private fun configureLockScreenBreakthrough() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val km = getSystemService(KeyguardManager::class.java)
            km?.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun handleSnooze(app: WakeLockApplication, alarm: AlarmEntity) {
        activeMissionCompleted = true
        lifecycleScope.launch {
            val snoozeUntil = System.currentTimeMillis() + alarm.snoozeDurationMinutes * 60_000L
            val updated = alarm.copy(
                currentSnoozeCount = alarm.currentSnoozeCount + 1,
                snoozedUntilMillis = snoozeUntil,
                nextTriggerTimeMillis = snoozeUntil
            )
            app.alarmRepository.updateAlarm(updated)
            app.alarmScheduler.scheduleAlarm(updated, snoozeUntil)
            AlarmService.stopActiveAlarm(this@AlarmRingingActivity)
            finish()
        }
    }

    private fun handleMissionSuccess(
        app: WakeLockApplication,
        alarm: AlarmEntity,
        attempts: Int,
        bestScore: Float,
        usedFallback: Boolean
    ) {
        activeMissionCompleted = true
        AlarmService.setCameraSessionActive(false)
        AlarmService.stopActiveAlarm(this@AlarmRingingActivity)

        lifecycleScope.launch {
            // Log mission completion
            app.alarmRepository.recordMissionCompletion(
                MissionLogEntity(
                    alarmId = alarm.id,
                    alarmLabel = alarm.label,
                    missionType = alarm.missionType,
                    completedAtMillis = System.currentTimeMillis(),
                    attemptsTaken = attempts.coerceAtLeast(1),
                    bestSimilarityScore = bestScore,
                    usedEmergencyFallback = usedFallback
                )
            )

            // Update alarm state: if one-time, disable; if repeating, schedule next occurrence
            if (alarm.repeatDays.isEmpty()) {
                app.alarmRepository.updateAlarm(
                    alarm.copy(
                        isEnabled = false,
                        currentSnoozeCount = 0,
                        snoozedUntilMillis = null,
                        nextTriggerTimeMillis = 0L
                    )
                )
                app.alarmScheduler.cancelAlarm(alarm.id)
            } else {
                val nextTrigger = AlarmTimeCalculator.computeNextTriggerMillis(
                    hour = alarm.hour,
                    minute = alarm.minute,
                    repeatDays = alarm.repeatDays
                )
                val updated = alarm.copy(
                    isEnabled = true,
                    currentSnoozeCount = 0,
                    snoozedUntilMillis = null,
                    nextTriggerTimeMillis = nextTrigger
                )
                app.alarmRepository.updateAlarm(updated)
                app.alarmScheduler.scheduleAlarm(updated, nextTrigger)
            }

            if (alarm.wakeUpCheckEnabled) {
                app.alarmScheduler.scheduleWakeUpCheck(alarm.id, alarm.label, delayMinutes = 5)
            }
        }
    }

    override fun onDestroy() {
        AlarmService.setCameraSessionActive(false)
        super.onDestroy()
    }
}

private enum class RingingViewMode {
    MAIN_RINGING,
    LIVE_PHOTO_CAMERA,
    MATH_CHALLENGE,
    SHAKE_CHALLENGE,
    SUCCESS_CELEBRATION
}

@Composable
private fun AlarmRingingRootScreen(
    alarm: AlarmEntity,
    app: WakeLockApplication,
    onSnoozeTriggered: (AlarmEntity) -> Unit,
    onMissionCompleted: (AlarmEntity, Int, Float, Boolean) -> Unit
) {
    val context = LocalContext.current
    var viewMode by remember { mutableStateOf(RingingViewMode.MAIN_RINGING) }
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var failedPhotoAttempts by remember { mutableIntStateOf(0) }
    var bestSimilarityAchieved by remember { mutableFloatStateOf(0f) }
    var referenceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var usedFallback by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(1000L)
        }
    }

    LaunchedEffect(alarm.referencePhotoPath) {
        if (!alarm.referencePhotoPath.isNullOrBlank()) {
            referenceBitmap = app.photoStorage.loadReferenceBitmap(alarm.referencePhotoPath)
        }
    }

    when (viewMode) {
        RingingViewMode.MAIN_RINGING -> {
            MainAlarmLandingView(
                alarm = alarm,
                nowMillis = nowMillis,
                referenceBitmap = referenceBitmap,
                onStartMissionClick = {
                    AlarmService.attenuateAudioForMission(context)
                    viewMode = when (alarm.missionType) {
                        MissionType.PHOTO -> RingingViewMode.LIVE_PHOTO_CAMERA
                        MissionType.MATH -> RingingViewMode.MATH_CHALLENGE
                        MissionType.SHAKE -> RingingViewMode.SHAKE_CHALLENGE
                        MissionType.NONE -> {
                            onMissionCompleted(alarm, 1, 100f, false)
                            RingingViewMode.SUCCESS_CELEBRATION
                        }
                    }
                },
                onSnoozeClick = { onSnoozeTriggered(alarm) }
            )
        }

        RingingViewMode.LIVE_PHOTO_CAMERA -> {
            LiveCameraPhotoMissionView(
                alarm = alarm,
                app = app,
                referenceBitmap = referenceBitmap,
                failedAttempts = failedPhotoAttempts,
                onMatchSuccess = { breakdown ->
                    bestSimilarityAchieved = maxOf(bestSimilarityAchieved, breakdown.overallScore)
                    onMissionCompleted(alarm, failedPhotoAttempts + 1, bestSimilarityAchieved, false)
                    viewMode = RingingViewMode.SUCCESS_CELEBRATION
                },
                onMatchFailure = { breakdown ->
                    failedPhotoAttempts++
                    bestSimilarityAchieved = maxOf(bestSimilarityAchieved, breakdown.overallScore)
                },
                onSwitchToEmergencyMath = {
                    usedFallback = true
                    viewMode = RingingViewMode.MATH_CHALLENGE
                },
                onBackToAlarmLanding = {
                    AlarmService.setCameraSessionActive(false)
                    viewMode = RingingViewMode.MAIN_RINGING
                }
            )
        }

        RingingViewMode.MATH_CHALLENGE -> {
            MathChallengeView(
                difficultyLevel = if (usedFallback) 3 else alarm.mathDifficultyLevel,
                totalProblems = if (usedFallback) 5 else alarm.mathProblemCount,
                isEmergencyFallback = usedFallback,
                onAllSolved = {
                    onMissionCompleted(alarm, failedPhotoAttempts + 1, bestSimilarityAchieved, usedFallback)
                    viewMode = RingingViewMode.SUCCESS_CELEBRATION
                }
            )
        }

        RingingViewMode.SHAKE_CHALLENGE -> {
            ShakeChallengeView(
                targetShakes = alarm.shakeTargetCount,
                onCompleted = {
                    onMissionCompleted(alarm, 1, 100f, false)
                    viewMode = RingingViewMode.SUCCESS_CELEBRATION
                }
            )
        }

        RingingViewMode.SUCCESS_CELEBRATION -> {
            MissionSuccessCelebrationView(
                alarm = alarm,
                bestScore = bestSimilarityAchieved,
                attempts = failedPhotoAttempts + 1,
                usedFallback = usedFallback,
                onFinish = {
                    (context as? ComponentActivity)?.finish()
                }
            )
        }
    }
}

private fun AlarmService.Companion.attenuateAudioForMission(context: Context) {
    attenuateAudioForCamera(context)
}

@Composable
private fun MainAlarmLandingView(
    alarm: AlarmEntity,
    nowMillis: Long,
    referenceBitmap: Bitmap?,
    onStartMissionClick: () -> Unit,
    onSnoozeClick: () -> Unit
) {
    val zdt = java.time.Instant.ofEpochMilli(nowMillis).atZone(java.time.ZoneId.systemDefault())
    val (timeStr, amPmStr) = AlarmTimeCalculator.formatTimeDisplay(zdt.hour, zdt.minute, false)
    val canSnooze = alarm.snoozeEnabled && (alarm.currentSnoozeCount < alarm.maxSnoozeCount)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(modifier = Modifier.height(28.dp))
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(50)
            ) {
                Text(
                    text = "ACTIVE SMART ALARM • BACK & HOME LOCKED",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }
            Spacer(modifier = Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = timeStr,
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
                if (amPmStr.isNotEmpty()) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = amPmStr,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = alarm.label,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )
        }

        // Target Reference Preview Card (if Photo Mission)
        if (alarm.missionType == MissionType.PHOTO && referenceBitmap != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Required Photo Mission Target Scene",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Image(
                        bitmap = referenceBitmap.asImageBitmap(),
                        contentDescription = "Target Reference Photograph",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .clip(RoundedCornerShape(16.dp))
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Walk to this exact scene and capture a live photo (${alarm.matchingDifficulty.label} difficulty)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = onStartMissionClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp),
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(
                    imageVector = when (alarm.missionType) {
                        MissionType.PHOTO -> Icons.Default.CameraAlt
                        MissionType.MATH -> Icons.Default.Calculate
                        MissionType.SHAKE -> Icons.Default.Vibration
                        MissionType.NONE -> Icons.Default.CheckCircle
                    },
                    contentDescription = null,
                    modifier = Modifier.size(26.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = when (alarm.missionType) {
                        MissionType.PHOTO -> "Start Photo Mission"
                        MissionType.MATH -> "Start Math Mission"
                        MissionType.SHAKE -> "Start Shake Mission"
                        MissionType.NONE -> "Dismiss Alarm"
                    },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            if (canSnooze) {
                val remainingSnoozes = alarm.maxSnoozeCount - alarm.currentSnoozeCount
                FilledTonalButton(
                    onClick = onSnoozeClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Default.Snooze, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Snooze ${alarm.snoozeDurationMinutes}m ($remainingSnoozes left)",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            } else if (alarm.snoozeEnabled) {
                Text(
                    text = "Maximum snooze limit (${alarm.maxSnoozeCount}) reached. Complete mission to dismiss.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

/**
 * Live CameraX Photo Mission Verifier.
 *
 * STRICT ENFORCEMENT:
 * - Uses CameraX `PreviewView` + `ImageCapture` bound to lifecycle.
 * - Captures in-memory `ImageProxy` frames directly from the active hardware camera sensor.
 * - NO gallery button, NO file chooser, NO screenshot acceptance.
 */
@Composable
private fun LiveCameraPhotoMissionView(
    alarm: AlarmEntity,
    app: WakeLockApplication,
    referenceBitmap: Bitmap?,
    failedAttempts: Int,
    onMatchSuccess: (VerificationBreakdown) -> Unit,
    onMatchFailure: (VerificationBreakdown) -> Unit,
    onSwitchToEmergencyMath: () -> Unit,
    onBackToAlarmLanding: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    var verificationStage by remember { mutableStateOf(VerificationStage.IDLE) }
    var lastBreakdown by remember { mutableStateOf<VerificationBreakdown?>(null) }
    var showGhostOverlay by remember { mutableStateOf(true) }
    var torchEnabled by remember { mutableStateOf(false) }
    var cameraErrorText by remember { mutableStateOf<String?>(null) }

    val imageCapture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()
    }
    var cameraControl by remember { mutableStateOf<CameraControl?>(null) }
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(Unit) {
        AlarmService.setCameraSessionActive(true)
        onDispose {
            AlarmService.setCameraSessionActive(false)
            cameraExecutor.shutdown()
        }
    }

    if (!hasCameraPermission) {
        // Graceful handling of Camera Permission Denial during active alarm
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.ErrorOutline,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Camera Permission Required for Live Photo Mission",
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Photo Mission requires live camera access to verify your target scene on-device. Gallery selection is disabled during active alarms.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Grant Camera Permission")
            }
            if (alarm.allowEmergencyMathFallback) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onSwitchToEmergencyMath,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Use Emergency Math Fallback (5 Equations)")
                }
            }
        }
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // 1. Live CameraX PreviewView
        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }
                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    runCatching {
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = androidx.camera.core.Preview.Builder().build().also {
                            it.surfaceProvider = previewView.surfaceProvider
                        }
                        cameraProvider.unbindAll()
                        val camera = cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            CameraSelector.DEFAULT_BACK_CAMERA,
                            preview,
                            imageCapture
                        )
                        cameraControl = camera.cameraControl
                    }.onFailure { err ->
                        cameraErrorText = "Camera initialization error: ${err.localizedMessage}"
                    }
                }, ContextCompat.getMainExecutor(ctx))
                previewView
            },
            modifier = Modifier.fillMaxSize()
        )

        // 2. Semi-transparent Ghost Reference Overlay (helps user align angle & framing in the morning!)
        if (showGhostOverlay && referenceBitmap != null) {
            Image(
                bitmap = referenceBitmap.asImageBitmap(),
                contentDescription = "Ghost Alignment Overlay",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(0.28f)
            )
        }

        // 3. Target Viewfinder Reticle Border
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 28.dp, vertical = 120.dp)
                .border(
                    width = 2.dp,
                    color = when (verificationStage) {
                        VerificationStage.MATCHED -> Color(0xFF10B981)
                        VerificationStage.NOT_MATCHED -> Color(0xFFEF4444)
                        else -> Color.White.copy(alpha = 0.7f)
                    },
                    shape = RoundedCornerShape(24.dp)
                )
        )

        // 4. Top Status Bar & Reference Thumbnail + Torch & Ghost Toggles
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .background(Color.Black.copy(alpha = 0.65f))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (referenceBitmap != null) {
                        Image(
                            bitmap = referenceBitmap.asImageBitmap(),
                            contentDescription = "Target Thumbnail",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                    }
                    Column {
                        Text(
                            text = "LIVE PHOTO MISSION",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = verificationStage.statusText,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White
                        )
                    }
                }

                Row {
                    IconButton(
                        onClick = { showGhostOverlay = !showGhostOverlay }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = "Toggle Reference Ghost Overlay",
                            tint = if (showGhostOverlay) MaterialTheme.colorScheme.secondary else Color.White
                        )
                    }
                    IconButton(
                        onClick = {
                            torchEnabled = !torchEnabled
                            cameraControl?.enableTorch(torchEnabled)
                        }
                    ) {
                        Icon(
                            imageVector = if (torchEnabled) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                            contentDescription = "Toggle Flashlight",
                            tint = if (torchEnabled) Color.Yellow else Color.White
                        )
                    }
                }
            }

            if (verificationStage == VerificationStage.ANALYZING || verificationStage == VerificationStage.COMPARING) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
        }

        // 5. Bottom Verification Feedback & Live Capture Trigger
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.78f))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (cameraErrorText != null) {
                Text(
                    text = cameraErrorText!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            AnimatedVisibility(visible = lastBreakdown != null) {
                val breakdown = lastBreakdown
                if (breakdown != null) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (breakdown.isMatched) {
                                Color(0xFF064E3B)
                            } else {
                                Color(0xFF450A0A)
                            }
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "${breakdown.userFeedbackMessage} (Score: ${breakdown.overallScore.roundToInt()} / ${breakdown.requiredThreshold.roundToInt()} required)",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White
                            )
                            Text(
                                text = breakdown.coachingTip,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                    }
                }
            }

            // Capture Button
            val isBusy = verificationStage == VerificationStage.CAPTURING ||
                verificationStage == VerificationStage.ANALYZING ||
                verificationStage == VerificationStage.COMPARING

            Button(
                onClick = {
                    if (isBusy) return@Button
                    AlarmService.attenuateAudioForMission(context)
                    verificationStage = VerificationStage.CAPTURING

                    imageCapture.takePicture(
                        cameraExecutor,
                        object : ImageCapture.OnImageCapturedCallback() {
                            override fun onCaptureSuccess(image: ImageProxy) {
                                val capturedBitmap = imageProxyToRotatedBitmap(image)
                                image.close()

                                scope.launch {
                                    verificationStage = VerificationStage.ANALYZING
                                    delay(180L) // Brief UI state visibility for "Analyzing photograph..."

                                    val liveFingerprint = withContext(Dispatchers.Default) {
                                        app.featureExtractor.extractFingerprint(capturedBitmap)
                                    }

                                    verificationStage = VerificationStage.COMPARING
                                    delay(180L) // Brief UI state visibility for "Comparing with reference..."

                                    val refFingerprint = app.featureExtractor.deserializeFingerprint(
                                        alarm.referenceFingerprintJson
                                    ) ?: referenceBitmap?.let {
                                        app.featureExtractor.extractFingerprint(it)
                                    }

                                    if (refFingerprint == null) {
                                        // Should not happen, but handle gracefully
                                        verificationStage = VerificationStage.MATCHED
                                        return@launch
                                    }

                                    val result = withContext(Dispatchers.Default) {
                                        app.similarityEngine.verify(
                                            reference = refFingerprint,
                                            liveCapture = liveFingerprint,
                                            difficulty = alarm.matchingDifficulty,
                                            customThreshold = alarm.customSimilarityThreshold
                                        )
                                    }

                                    lastBreakdown = result
                                    if (result.isMatched) {
                                        verificationStage = VerificationStage.MATCHED
                                        delay(500L)
                                        onMatchSuccess(result)
                                    } else {
                                        verificationStage = VerificationStage.NOT_MATCHED
                                        onMatchFailure(result)
                                    }
                                }
                            }

                            override fun onError(exception: ImageCaptureException) {
                                scope.launch {
                                    verificationStage = VerificationStage.NOT_MATCHED
                                    cameraErrorText = "Camera capture failed: ${exception.localizedMessage}. Please try again."
                                }
                            }
                        }
                    )
                },
                enabled = !isBusy,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(62.dp),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(26.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = if (isBusy) verificationStage.statusText else "Capture Live Photo to Verify",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                OutlinedButton(onClick = onBackToAlarmLanding) {
                    Text("Back to Alarm", color = Color.White)
                }

                if (alarm.allowEmergencyMathFallback && failedAttempts >= 3) {
                    FilledTonalButton(onClick = onSwitchToEmergencyMath) {
                        Text("Away from scene? Solve 5 Hard Math")
                    }
                }
            }
        }
    }
}

private fun imageProxyToRotatedBitmap(image: ImageProxy): Bitmap {
    val rawBitmap = image.toBitmap()
    val rotation = image.imageInfo.rotationDegrees
    if (rotation == 0) return rawBitmap
    val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
    return Bitmap.createBitmap(rawBitmap, 0, 0, rawBitmap.width, rawBitmap.height, matrix, true)
}

@Composable
private fun MathChallengeView(
    difficultyLevel: Int,
    totalProblems: Int,
    isEmergencyFallback: Boolean,
    onAllSolved: () -> Unit
) {
    var currentProblemIndex by remember { mutableIntStateOf(1) }
    var userInput by remember { mutableStateOf("") }
    var errorHint by remember { mutableStateOf<String?>(null) }

    val (questionText, expectedAnswer) = remember(currentProblemIndex, difficultyLevel) {
        generateMathProblem(difficultyLevel)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = if (isEmergencyFallback) "Emergency Math Fallback" else "Math Wake-Up Mission",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Problem $currentProblemIndex of $totalProblems",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(24.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = questionText,
                    style = MaterialTheme.typography.displayMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(20.dp))
                OutlinedTextField(
                    value = userInput,
                    onValueChange = {
                        userInput = it
                        errorHint = null
                    },
                    label = { Text("Enter Answer") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorHint != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = errorHint!!, color = MaterialTheme.colorScheme.error)
                }
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        val parsed = userInput.trim().toIntOrNull()
                        if (parsed == expectedAnswer) {
                            userInput = ""
                            if (currentProblemIndex >= totalProblems) {
                                onAllSolved()
                            } else {
                                currentProblemIndex++
                            }
                        } else {
                            errorHint = "Incorrect answer. Focus and try again!"
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                ) {
                    Text("Submit Answer", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

private fun generateMathProblem(level: Int): Pair<String, Int> {
    return when (level) {
        1 -> {
            val a = Random.nextInt(12, 49)
            val b = Random.nextInt(11, 39)
            "$a + $b = ?" to (a + b)
        }
        2 -> {
            val a = Random.nextInt(6, 15)
            val b = Random.nextInt(7, 14)
            val c = Random.nextInt(10, 35)
            "($a × $b) + $c = ?" to (a * b + c)
        }
        else -> {
            val a = Random.nextInt(12, 24)
            val b = Random.nextInt(8, 17)
            val c = Random.nextInt(15, 45)
            "($a × $b) - $c = ?" to (a * b - c)
        }
    }
}

@Composable
private fun ShakeChallengeView(
    targetShakes: Int,
    onCompleted: () -> Unit
) {
    val context = LocalContext.current
    var shakesDone by remember { mutableIntStateOf(0) }

    DisposableEffect(targetShakes) {
        val sensorManager = context.getSystemService(SensorManager::class.java)
        val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        var lastShakeTimestamp = 0L

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                val values = event?.values ?: return
                val ax = values[0]
                val ay = values[1]
                val az = values[2]
                val gForce = sqrt(ax * ax + ay * ay + az * az) / SensorManager.GRAVITY_EARTH
                if (gForce > 2.2f) {
                    val now = System.currentTimeMillis()
                    if (now - lastShakeTimestamp > 220L) {
                        lastShakeTimestamp = now
                        shakesDone++
                        if (shakesDone >= targetShakes) {
                            onCompleted()
                        }
                    }
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        if (accelerometer != null) {
            sensorManager.registerListener(listener, accelerometer, SensorManager.SENSOR_DELAY_UI)
        }

        onDispose {
            sensorManager?.unregisterListener(listener)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Vibration,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text("Shake Phone Vigorously!", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "${shakesDone.coerceAtMost(targetShakes)} / $targetShakes",
            style = MaterialTheme.typography.displayLarge,
            color = MaterialTheme.colorScheme.secondary
        )
        Spacer(modifier = Modifier.height(20.dp))
        LinearProgressIndicator(
            progress = { (shakesDone.toFloat() / targetShakes.toFloat()).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(50))
        )
    }
}

@Composable
private fun MissionSuccessCelebrationView(
    alarm: AlarmEntity,
    bestScore: Float,
    attempts: Int,
    usedFallback: Boolean,
    onFinish: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.size(64.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Photograph Matched! Alarm Dismissed",
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = if (alarm.missionType == MissionType.PHOTO && !usedFallback) {
                "Verified live scene similarity: ${bestScore.roundToInt()}% on attempt #$attempts. Ringtone & vibration stopped."
            } else {
                "Wake-Up Mission verified on attempt #$attempts. Ringtone & vibration stopped."
            },
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )

        if (alarm.wakeUpCheckEnabled) {
            Spacer(modifier = Modifier.height(12.dp))
            Surface(
                color = MaterialTheme.colorScheme.secondaryContainer,
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = "5-Minute Post-Alarm Wake-Up Check is active.",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        Button(
            onClick = onFinish,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(18.dp)
        ) {
            Text("Done — Start My Day", style = MaterialTheme.typography.titleLarge)
        }
    }
}
