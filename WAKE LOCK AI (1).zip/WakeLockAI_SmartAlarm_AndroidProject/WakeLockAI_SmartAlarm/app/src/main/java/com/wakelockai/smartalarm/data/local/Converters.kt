package com.wakelockai.smartalarm.data.local

import androidx.room.TypeConverter
import com.wakelockai.smartalarm.domain.model.MatchingDifficulty
import com.wakelockai.smartalarm.domain.model.MissionType
import com.wakelockai.smartalarm.domain.model.VibrationPattern

class Converters {

    @TypeConverter
    fun fromIntSet(days: Set<Int>): String {
        return days.sorted().joinToString(",")
    }

    @TypeConverter
    fun toIntSet(data: String): Set<Int> {
        if (data.isBlank()) return emptySet()
        return data.split(",").mapNotNull { it.trim().toIntOrNull() }.toSet()
    }

    @TypeConverter
    fun fromMissionType(type: MissionType): String = type.name

    @TypeConverter
    fun toMissionType(value: String): MissionType =
        runCatching { MissionType.valueOf(value) }.getOrDefault(MissionType.PHOTO)

    @TypeConverter
    fun fromMatchingDifficulty(difficulty: MatchingDifficulty): String = difficulty.name

    @TypeConverter
    fun toMatchingDifficulty(value: String): MatchingDifficulty =
        runCatching { MatchingDifficulty.valueOf(value) }.getOrDefault(MatchingDifficulty.NORMAL)

    @TypeConverter
    fun fromVibrationPattern(pattern: VibrationPattern): String = pattern.name

    @TypeConverter
    fun toVibrationPattern(value: String): VibrationPattern =
        runCatching { VibrationPattern.valueOf(value) }.getOrDefault(VibrationPattern.HEARTBEAT)
}
