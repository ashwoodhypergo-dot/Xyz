package com.wakelockai.smartalarm.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.wakelockai.smartalarm.domain.model.ThemeMode

private val AmoledDarkColorScheme = darkColorScheme(
    primary = SolarCoral,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF3B1D16),
    onPrimaryContainer = Color(0xFFFFDAD2),
    secondary = ElectricCyan,
    onSecondary = Color(0xFF002024),
    secondaryContainer = Color(0xFF0C353C),
    onSecondaryContainer = Color(0xFFB4F6FF),
    tertiary = EmeraldSuccess,
    background = MidnightBg,
    onBackground = Color(0xFFF0F4F8),
    surface = MidnightSurface,
    onSurface = Color(0xFFF0F4F8),
    surfaceVariant = MidnightSurfaceElevated,
    onSurfaceVariant = Color(0xFFA6B4C8),
    error = CrimsonDanger,
    onError = Color.White
)

private val CleanLightColorScheme = lightColorScheme(
    primary = DaylightPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDBD2),
    onPrimaryContainer = Color(0xFF3E0500),
    secondary = DaylightSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFC4F3FC),
    onSecondaryContainer = Color(0xFF001F24),
    tertiary = EmeraldSuccess,
    background = DaylightBg,
    onBackground = Color(0xFF141A22),
    surface = DaylightSurface,
    onSurface = Color(0xFF141A22),
    surfaceVariant = DaylightSurfaceVariant,
    onSurfaceVariant = Color(0xFF4A5568),
    error = CrimsonDanger,
    onError = Color.White
)

@Composable
fun WakeLockAITheme(
    themeMode: ThemeMode = ThemeMode.DARK_AMOLED,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        ThemeMode.DARK_AMOLED -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (isDark) AmoledDarkColorScheme else CleanLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = WakeLockTypography,
        content = content
    )
}
