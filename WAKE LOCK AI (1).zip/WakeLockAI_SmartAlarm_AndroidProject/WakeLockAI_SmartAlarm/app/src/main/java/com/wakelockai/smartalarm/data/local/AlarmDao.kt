package com.wakelockai.smartalarm.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AlarmDao {

    @Query("SELECT * FROM alarms ORDER BY hour ASC, minute ASC")
    fun observeAllAlarms(): Flow<List<AlarmEntity>>

    @Query("SELECT * FROM alarms ORDER BY hour ASC, minute ASC")
    suspend fun getAllAlarmsOnce(): List<AlarmEntity>

    @Query("SELECT * FROM alarms WHERE isEnabled = 1")
    suspend fun getEnabledAlarmsOnce(): List<AlarmEntity>

    @Query("SELECT * FROM alarms WHERE id = :alarmId LIMIT 1")
    suspend fun getAlarmById(alarmId: Long): AlarmEntity?

    @Query("SELECT * FROM alarms WHERE id = :alarmId LIMIT 1")
    fun observeAlarmById(alarmId: Long): Flow<AlarmEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlarm(alarm: AlarmEntity): Long

    @Update
    suspend fun updateAlarm(alarm: AlarmEntity)

    @Delete
    suspend fun deleteAlarm(alarm: AlarmEntity)

    @Query("DELETE FROM alarms WHERE id = :alarmId")
    suspend fun deleteAlarmById(alarmId: Long)

    @Query("UPDATE alarms SET referencePhotoPath = NULL, referencePhotoSha256 = NULL, referenceFingerprintJson = NULL, missionType = 'NONE' WHERE referencePhotoPath IS NOT NULL")
    suspend fun clearAllReferencePhotosInDb()

    @Query("DELETE FROM alarms")
    suspend fun deleteAllAlarms()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMissionLog(log: MissionLogEntity)

    @Query("SELECT * FROM mission_logs ORDER BY completedAtMillis DESC LIMIT 50")
    fun observeRecentMissionLogs(): Flow<List<MissionLogEntity>>

    @Query("DELETE FROM mission_logs")
    suspend fun clearMissionLogs()
}
