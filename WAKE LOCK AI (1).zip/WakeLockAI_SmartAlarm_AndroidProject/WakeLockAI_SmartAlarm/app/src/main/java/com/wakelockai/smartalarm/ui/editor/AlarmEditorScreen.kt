package com.wakelockai.smartalarm.ui.editor

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.media.RingtoneManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wakelockai.smartalarm.data.local.AlarmEntity
import com.wakelockai.smartalarm.domain.model.MatchingDifficulty
import com.wakelockai.smartalarm.domain.model.MissionType
import com.wakelockai.smartalarm.domain.model.SceneFingerprint
import com.wakelockai.smartalarm.domain.model.VibrationPattern
import com.wakelockai.smartalarm.ui.navigation.MainViewModel
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AlarmEditorScreen(
    initialAlarm: AlarmEntity,
    isNewAlarm: Boolean,
    use24Hour: Boolean,
    viewModel: MainViewModel,
    onDismiss: () -> Unit,
    onSave: (AlarmEntity) -> Unit,
    onDelete: (AlarmEntity) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val timePickerState = rememberTimePickerState(
        initialHour = initialAlarm.hour,
        initialMinute = initialAlarm.minute,
        is24Hour = use24Hour
    )

    var label by remember { mutableStateOf(initialAlarm.label) }
    var repeatDays by remember { mutableStateOf(initialAlarm.repeatDays) }
    var ringtoneUri by remember { mutableStateOf(initialAlarm.ringtoneUri) }
    var ringtoneTitle by remember { mutableStateOf(initialAlarm.ringtoneTitle) }
    var alarmVolume by remember { mutableFloatStateOf(initialAlarm.alarmVolume) }
    var progressiveRampSeconds by remember { mutableIntStateOf(initialAlarm.progressiveVolumeRampSeconds) }
    var vibrationEnabled by remember { mutableStateOf(initialAlarm.vibrationEnabled) }
    var vibrationPattern by remember { mutableStateOf(initialAlarm.vibrationPattern) }

    var snoozeEnabled by remember { mutableStateOf(initialAlarm.snoozeEnabled) }
    var snoozeDurationMinutes by remember { mutableIntStateOf(initialAlarm.snoozeDurationMinutes) }
    var maxSnoozeCount by remember { mutableIntStateOf(initialAlarm.maxSnoozeCount) }

    var missionType by remember { mutableStateOf(initialAlarm.missionType) }
    var referencePhotoPath by remember { mutableStateOf(initialAlarm.referencePhotoPath) }
    var referencePhotoSha256 by remember { mutableStateOf(initialAlarm.referencePhotoSha256) }
    var referenceFingerprintJson by remember { mutableStateOf(initialAlarm.referenceFingerprintJson) }
    var matchingDifficulty by remember { mutableStateOf(initialAlarm.matchingDifficulty) }
    var customThreshold by remember { mutableFloatStateOf(initialAlarm.customSimilarityThreshold) }

    var mathDifficultyLevel by remember { mutableIntStateOf(initialAlarm.mathDifficultyLevel) }
    var mathProblemCount by remember { mutableIntStateOf(initialAlarm.mathProblemCount) }
    var shakeTargetCount by remember { mutableIntStateOf(initialAlarm.shakeTargetCount) }
    var allowEmergencyFallback by remember { mutableStateOf(initialAlarm.allowEmergencyMathFallback) }
    var wakeUpCheckEnabled by remember { mutableStateOf(initialAlarm.wakeUpCheckEnabled) }
    var flashlightStrobeEnabled by remember { mutableStateOf(initialAlarm.flashlightStrobeEnabled) }

    var referenceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var extractedFingerprint by remember { mutableStateOf<SceneFingerprint?>(null) }
    var isProcessingPhoto by remember { mutableStateOf(false) }
    var photoErrorMessage by remember { mutableStateOf<String?>(null) }
    var showValidationDialog by remember { mutableStateOf(false) }

    // Load existing reference bitmap & fingerprint on launch
    LaunchedEffect(referencePhotoPath) {
        if (!referencePhotoPath.isNullOrBlank() && referenceBitmap == null) {
            referenceBitmap = viewModel.photoStorage.loadReferenceBitmap(referencePhotoPath)
            extractedFingerprint = viewModel.featureExtractor.deserializeFingerprint(referenceFingerprintJson)
        }
    }

    // Gallery Picker ONLY allowed during alarm setup (strictly prohibited during alarm ringing!)
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            isProcessingPhoto = true
            photoErrorMessage = null
            scope.launch {
                val res = viewModel.processAndSaveReferencePhoto(uri, referencePhotoPath)
                isProcessingPhoto = false
                res.onSuccess { (savedPhoto, fingerprint, fpJson) ->
                    referencePhotoPath = savedPhoto.absolutePath
                    referencePhotoSha256 = savedPhoto.sha256Hex
                    referenceFingerprintJson = fpJson
                    referenceBitmap = savedPhoto.bitmap
                    extractedFingerprint = fingerprint
                }.onFailure { err ->
                    photoErrorMessage = err.message ?: "Failed to analyze selected photograph."
                }
            }
        }
    }

    // Legacy GetContent fallback launcher if device lacks PhotoPicker
    val fallbackGalleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            isProcessingPhoto = true
            photoErrorMessage = null
            scope.launch {
                val res = viewModel.processAndSaveReferencePhoto(uri, referencePhotoPath)
                isProcessingPhoto = false
                res.onSuccess { (savedPhoto, fingerprint, fpJson) ->
                    referencePhotoPath = savedPhoto.absolutePath
                    referencePhotoSha256 = savedPhoto.sha256Hex
                    referenceFingerprintJson = fpJson
                    referenceBitmap = savedPhoto.bitmap
                    extractedFingerprint = fingerprint
                }.onFailure { err ->
                    photoErrorMessage = err.message ?: "Failed to analyze selected photograph."
                }
            }
        }
    }

    // System Ringtone Picker Launcher
    val ringtonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri: Uri? = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            if (uri != null) {
                ringtoneUri = uri.toString()
                val ringtone = RingtoneManager.getRingtone(context, uri)
                ringtoneTitle = ringtone?.getTitle(context) ?: "Custom Alarm Tone"
            }
        }
    }

    if (showValidationDialog) {
        AlertDialog(
            onDismissRequest = { showValidationDialog = false },
            title = { Text("Reference Photograph Required") },
            text = {
                Text("You selected Photo Mission, which requires a reference photograph from your gallery so the on-device AI can extract its visual embedding. Please select a reference photo or choose another mission type.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showValidationDialog = false
                        runCatching {
                            galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }.onFailure {
                            fallbackGalleryLauncher.launch("image/*")
                        }
                    }
                ) {
                    Text("Select Reference Photo")
                }
            },
            dismissButton = {
                TextButton(onClick = { showValidationDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isNewAlarm) "Create Smart Alarm" else "Edit Smart Alarm") },
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Cancel")
                    }
                },
                actions = {
                    if (!isNewAlarm) {
                        IconButton(onClick = { onDelete(initialAlarm) }) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = "Delete Alarm",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                    Button(
                        onClick = {
                            if (missionType == MissionType.PHOTO &&
                                (referencePhotoPath.isNullOrBlank() || referenceFingerprintJson.isNullOrBlank())
                            ) {
                                showValidationDialog = true
                                return@Button
                            }
                            val effectiveThreshold = if (matchingDifficulty == MatchingDifficulty.CUSTOM) {
                                customThreshold
                            } else {
                                matchingDifficulty.defaultThreshold
                            }
                            onSave(
                                initialAlarm.copy(
                                    hour = timePickerState.hour,
                                    minute = timePickerState.minute,
                                    label = label.ifBlank { "Smart Alarm" },
                                    isEnabled = true,
                                    repeatDays = repeatDays,
                                    ringtoneUri = ringtoneUri,
                                    ringtoneTitle = ringtoneTitle,
                                    alarmVolume = alarmVolume,
                                    progressiveVolumeRampSeconds = progressiveRampSeconds,
                                    vibrationEnabled = vibrationEnabled,
                                    vibrationPattern = vibrationPattern,
                                    snoozeEnabled = snoozeEnabled,
                                    snoozeDurationMinutes = snoozeDurationMinutes,
                                    maxSnoozeCount = maxSnoozeCount,
                                    missionType = missionType,
                                    referencePhotoPath = referencePhotoPath,
                                    referencePhotoSha256 = referencePhotoSha256,
                                    referenceFingerprintJson = referenceFingerprintJson,
                                    matchingDifficulty = matchingDifficulty,
                                    customSimilarityThreshold = effectiveThreshold,
                                    mathDifficultyLevel = mathDifficultyLevel,
                                    mathProblemCount = mathProblemCount,
                                    shakeTargetCount = shakeTargetCount,
                                    allowEmergencyMathFallback = allowEmergencyFallback,
                                    wakeUpCheckEnabled = wakeUpCheckEnabled,
                                    flashlightStrobeEnabled = flashlightStrobeEnabled
                                )
                            )
                        },
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Alarm", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Native Material 3 Time Picker Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        TimePicker(state = timePickerState)
                    }
                }
            }

            // 2. Alarm Name & Weekday Repeat Selector
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        OutlinedTextField(
                            value = label,
                            onValueChange = { label = it },
                            label = { Text("Alarm Name") },
                            placeholder = { Text("e.g., Bathroom Washbasin Mission") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Repeat Days", style = MaterialTheme.typography.titleMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                TextButton(onClick = { repeatDays = setOf(1, 2, 3, 4, 5) }) {
                                    Text("Weekdays")
                                }
                                TextButton(onClick = { repeatDays = setOf(6, 7) }) {
                                    Text("Weekend")
                                }
                                TextButton(onClick = { repeatDays = if (repeatDays.size == 7) emptySet() else (1..7).toSet() }) {
                                    Text(if (repeatDays.size == 7) "Clear" else "Every Day")
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        val dayLetters = listOf(
                            1 to "M",
                            2 to "T",
                            3 to "W",
                            4 to "T",
                            5 to "F",
                            6 to "S",
                            7 to "S"
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            dayLetters.forEach { (dayNum, letter) ->
                                val isSelected = repeatDays.contains(dayNum)
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isSelected) MaterialTheme.colorScheme.primary
                                            else MaterialTheme.colorScheme.surfaceVariant
                                        )
                                        .clickable {
                                            repeatDays = if (isSelected) repeatDays - dayNum else repeatDays + dayNum
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = letter,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. Mission Selection & Complete Photo Mission Setup Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Wake-Up Mission & AI Scene Verification",
                                style = MaterialTheme.typography.titleLarge
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            MissionType.entries.forEach { type ->
                                FilterChip(
                                    selected = missionType == type,
                                    onClick = { missionType = type },
                                    label = { Text(type.displayName) }
                                )
                            }
                        }

                        Text(
                            text = missionType.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 6.dp)
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        when (missionType) {
                            MissionType.PHOTO -> {
                                PhotoMissionConfigurationSection(
                                    referenceBitmap = referenceBitmap,
                                    fingerprint = extractedFingerprint,
                                    isProcessing = isProcessingPhoto,
                                    errorMessage = photoErrorMessage,
                                    matchingDifficulty = matchingDifficulty,
                                    customThreshold = customThreshold,
                                    allowEmergencyFallback = allowEmergencyFallback,
                                    onPickFromGallery = {
                                        runCatching {
                                            galleryLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        }.onFailure {
                                            fallbackGalleryLauncher.launch("image/*")
                                        }
                                    },
                                    onDifficultyChange = { diff ->
                                        matchingDifficulty = diff
                                        if (diff != MatchingDifficulty.CUSTOM) {
                                            customThreshold = diff.defaultThreshold
                                        }
                                    },
                                    onCustomThresholdChange = { value ->
                                        matchingDifficulty = MatchingDifficulty.CUSTOM
                                        customThreshold = value
                                    },
                                    onEmergencyFallbackChange = { allowEmergencyFallback = it }
                                )
                            }

                            MissionType.MATH -> {
                                Column {
                                    Text(
                                        text = "Math Difficulty Level: $mathDifficultyLevel (1=Easy, 2=Normal, 3=Hard)",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Slider(
                                        value = mathDifficultyLevel.toFloat(),
                                        onValueChange = { mathDifficultyLevel = it.roundToInt().coerceIn(1, 3) },
                                        valueRange = 1f..3f,
                                        steps = 1
                                    )
                                    Text(
                                        text = "Number of Equations to Solve: $mathProblemCount",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Slider(
                                        value = mathProblemCount.toFloat(),
                                        onValueChange = { mathProblemCount = it.roundToInt().coerceIn(1, 10) },
                                        valueRange = 1f..10f,
                                        steps = 8
                                    )
                                }
                            }

                            MissionType.SHAKE -> {
                                Column {
                                    Text(
                                        text = "Vigorous Shakes Required: $shakeTargetCount shakes",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Slider(
                                        value = shakeTargetCount.toFloat(),
                                        onValueChange = { shakeTargetCount = (it / 5f).roundToInt() * 5 },
                                        valueRange = 10f..100f
                                    )
                                }
                            }

                            MissionType.NONE -> {
                                Text(
                                    text = "Standard alarm dismissal without a verification mission.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // 4. Sound, Volume, Progressive Ramp & Vibration Settings
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Ringtone, Volume & Vibration", style = MaterialTheme.typography.titleLarge)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Selected Ringtone", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = ringtoneTitle,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                            FilledTonalButton(
                                onClick = {
                                    val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select Alarm Tone")
                                    }
                                    runCatching { ringtonePickerLauncher.launch(intent) }
                                }
                            ) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Change Tone")
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "Alarm Volume: ${(alarmVolume * 100).roundToInt()}%",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Slider(
                            value = alarmVolume,
                            onValueChange = { alarmVolume = it.coerceIn(0.15f, 1.0f) },
                            valueRange = 0.15f..1.0f
                        )

                        Text(
                            text = if (progressiveRampSeconds == 0) {
                                "Volume Ramp-Up: Immediate 100% Volume"
                            } else {
                                "Progressive Volume Fade-In: ${progressiveRampSeconds}s"
                            },
                            style = MaterialTheme.typography.titleMedium
                        )
                        Slider(
                            value = progressiveRampSeconds.toFloat(),
                            onValueChange = { progressiveRampSeconds = (it / 5f).roundToInt() * 5 },
                            valueRange = 0f..60f
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Vibration, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Vibration", style = MaterialTheme.typography.titleMedium)
                            }
                            Switch(checked = vibrationEnabled, onCheckedChange = { vibrationEnabled = it })
                        }

                        if (vibrationEnabled) {
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(top = 6.dp)
                            ) {
                                VibrationPattern.entries.forEach { pat ->
                                    FilterChip(
                                        selected = vibrationPattern == pat,
                                        onClick = { vibrationPattern = pat },
                                        label = { Text(pat.displayName) }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FlashOn, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Flashlight Strobe Alert", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "Blinks camera LED while ringing",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(checked = flashlightStrobeEnabled, onCheckedChange = { flashlightStrobeEnabled = it })
                        }
                    }
                }
            }

            // 5. Snooze & Post-Alarm Wake-Up Check Configuration
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Snooze, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Snooze Configuration", style = MaterialTheme.typography.titleLarge)
                            }
                            Switch(checked = snoozeEnabled, onCheckedChange = { snoozeEnabled = it })
                        }

                        if (snoozeEnabled) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Snooze Duration: $snoozeDurationMinutes minutes", style = MaterialTheme.typography.titleMedium)
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(vertical = 6.dp)
                            ) {
                                listOf(1, 3, 5, 10, 15, 30).forEach { mins ->
                                    FilterChip(
                                        selected = snoozeDurationMinutes == mins,
                                        onClick = { snoozeDurationMinutes = mins },
                                        label = { Text("${mins}m") }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (maxSnoozeCount == 0) "Max Snooze Attempts: No Snoozes Allowed"
                                else "Maximum Snooze Attempts: $maxSnoozeCount times",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Slider(
                                value = maxSnoozeCount.toFloat(),
                                onValueChange = { maxSnoozeCount = it.roundToInt().coerceIn(1, 10) },
                                valueRange = 1f..10f,
                                steps = 8
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("5-Minute Wake-Up Check", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "Follows up 5 mins after Photo Mission dismissal to ensure you didn't go back to bed",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(checked = wakeUpCheckEnabled, onCheckedChange = { wakeUpCheckEnabled = it })
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PhotoMissionConfigurationSection(
    referenceBitmap: Bitmap?,
    fingerprint: SceneFingerprint?,
    isProcessing: Boolean,
    errorMessage: String?,
    matchingDifficulty: MatchingDifficulty,
    customThreshold: Float,
    allowEmergencyFallback: Boolean,
    onPickFromGallery: () -> Unit,
    onDifficultyChange: (MatchingDifficulty) -> Unit,
    onCustomThresholdChange: (Float) -> Unit,
    onEmergencyFallbackChange: (Boolean) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
            .padding(16.dp)
    ) {
        Text(
            text = "Step 1: Reference Scene Photograph (Setup Only)",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Select a clear photograph of a fixed household scene (e.g. bathroom washbasin, kitchen coffee maker, or bookshelf). When the alarm rings, gallery access is strictly locked—you must photograph this exact scene live.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (isProcessing) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Extracting 128-D neural scene embedding & keypoints on-device...")
                }
            }
        } else if (referenceBitmap != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
            ) {
                Image(
                    bitmap = referenceBitmap.asImageBitmap(),
                    contentDescription = "Selected Reference Photograph",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Surface(
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        val kpCount = fingerprint?.keypointDescriptors?.size ?: 0
                        Text(
                            text = "Stored Offline • 128-D Embedding + $kpCount Landmarks",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = onPickFromGallery,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Replace Reference Photograph")
            }
        } else {
            Button(
                onClick = onPickFromGallery,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) {
                Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Select Reference Photograph from Gallery", fontWeight = FontWeight.Bold)
            }
        }

        if (errorMessage != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = errorMessage,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Step 2: Visual Similarity Matching Difficulty",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(8.dp))

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MatchingDifficulty.entries.forEach { diff ->
                FilterChip(
                    selected = matchingDifficulty == diff,
                    onClick = { onDifficultyChange(diff) },
                    label = { Text(diff.label) }
                )
            }
        }

        val activeThreshold = if (matchingDifficulty == MatchingDifficulty.CUSTOM) {
            customThreshold
        } else {
            matchingDifficulty.defaultThreshold
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "${matchingDifficulty.angleToleranceHint} — Required Similarity Score: ${activeThreshold.roundToInt()} / 100",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.secondary
        )
        Text(
            text = matchingDifficulty.description,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "Advanced Manual Threshold Adjustment: ${activeThreshold.roundToInt()}%",
            style = MaterialTheme.typography.bodyMedium
        )
        Slider(
            value = activeThreshold,
            onValueChange = onCustomThresholdChange,
            valueRange = 50f..95f
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Away-From-Home Emergency Fallback", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "If you travel or cannot access the target room after 3 photo attempts, allow solving 5 hard arithmetic equations to dismiss.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = allowEmergencyFallback,
                onCheckedChange = onEmergencyFallbackChange
            )
        }
    }
}
