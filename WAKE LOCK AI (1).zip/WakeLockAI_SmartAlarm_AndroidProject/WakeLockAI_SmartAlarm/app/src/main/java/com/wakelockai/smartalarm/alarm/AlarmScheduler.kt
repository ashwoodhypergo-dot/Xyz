package com.wakelockai.smartalarm.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.wakelockai.smartalarm.MainActivity
import com.wakelockai.smartalarm.data.local.AlarmEntity

/**
 * Wraps Android's native AlarmManager using setAlarmClock() as primary mechanism.
 *
 * Why setAlarmClock()?
 * - Wakes the device out of Doze mode at the exact second.
 * - Displays the system status-bar alarm icon.
 * - Grants the target PendingIntent privileged background activity / foreground service start rights.
 * - Falls back gracefully to setExactAndAllowWhileIdle() if needed.
 */
class AlarmScheduler(private val context: Context) {

    private val alarmManager: AlarmManager?
        get() = context.getSystemService(AlarmManager::class.java)

    fun canScheduleExactAlarms(): Boolean {
        val am = alarmManager ?: return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            am.canScheduleExactAlarms()
        } else {
            true
        }
    }

    /**
     * Schedules an enabled AlarmEntity and returns the exact epoch timestamp (ms) scheduled.
     */
    fun scheduleAlarm(alarm: AlarmEntity, customTriggerMillis: Long? = null): Long {
        if (!alarm.isEnabled && customTriggerMillis == null) {
            cancelAlarm(alarm.id)
            return 0L
        }

        val triggerMillis = customTriggerMillis
            ?: alarm.snoozedUntilMillis?.takeIf { it > System.currentTimeMillis() }
            ?: AlarmTimeCalculator.computeNextTriggerMillis(
                hour = alarm.hour,
                minute = alarm.minute,
                repeatDays = alarm.repeatDays
            )

        val am = alarmManager ?: return triggerMillis

        val triggerIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_TRIGGER_ALARM
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, alarm.id)
            putExtra(AlarmReceiver.EXTRA_IS_SNOOZE, alarm.snoozedUntilMillis != null)
        }

        val operationPi = PendingIntent.getBroadcast(
            context,
            alarmRequestCode(alarm.id),
            triggerIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val showAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, alarm.id)
        }

        val showAppPi = PendingIntent.getActivity(
            context,
            showRequestCode(alarm.id),
            showAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            val clockInfo = AlarmManager.AlarmClockInfo(triggerMillis, showAppPi)
            am.setAlarmClock(clockInfo, operationPi)
        } catch (se: SecurityException) {
            // Fallback if exact alarm permission was revoked by user in system settings
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, operationPi)
        }

        return triggerMillis
    }

    /**
     * Schedules a 5-minute post-dismissal "Wake-Up Check" verification alert to prevent the user
     * from falling back asleep after completing the Photo Mission.
     */
    fun scheduleWakeUpCheck(alarmId: Long, alarmLabel: String, delayMinutes: Int = 5) {
        val am = alarmManager ?: return
        val triggerAt = System.currentTimeMillis() + delayMinutes * 60_000L

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_WAKE_UP_CHECK
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, alarmId)
            putExtra(AlarmReceiver.EXTRA_ALARM_LABEL, alarmLabel)
        }

        val pi = PendingIntent.getBroadcast(
            context,
            wakeUpCheckRequestCode(alarmId),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    fun cancelWakeUpCheck(alarmId: Long) {
        val am = alarmManager ?: return
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_WAKE_UP_CHECK
        }
        val pi = PendingIntent.getBroadcast(
            context,
            wakeUpCheckRequestCode(alarmId),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            am.cancel(pi)
            pi.cancel()
        }
    }

    fun cancelAlarm(alarmId: Long) {
        val am = alarmManager ?: return
        val triggerIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_TRIGGER_ALARM
        }
        val pi = PendingIntent.getBroadcast(
            context,
            alarmRequestCode(alarmId),
            triggerIntent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            am.cancel(pi)
            pi.cancel()
        }
        cancelWakeUpCheck(alarmId)
    }

    private fun alarmRequestCode(alarmId: Long): Int = (alarmId.toInt() and 0x0FFFFFFF) + 10_000
    private fun showRequestCode(alarmId: Long): Int = (alarmId.toInt() and 0x0FFFFFFF) + 20_000
    private fun wakeUpCheckRequestCode(alarmId: Long): Int = (alarmId.toInt() and 0x0FFFFFFF) + 30_000
}
