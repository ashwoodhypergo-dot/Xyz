package com.wakelockai.smartalarm.domain.model

import kotlinx.serialization.Serializable

@Serializable
enum class MissionType(val displayName: String, val description: String) {
    PHOTO(
        displayName = "Photo Mission",
        description = "Take a live photo matching your saved reference scene to dismiss"
    ),
    MATH(
        displayName = "Math Mission",
        description = "Solve mental arithmetic equations before the timer runs out"
    ),
    SHAKE(
        displayName = "Shake Mission",
        description = "Physically shake your phone vigorously using the accelerometer"
    ),
    NONE(
        displayName = "Standard Dismiss",
        description = "Slide or tap to dismiss immediately without a verification challenge"
    )
}

@Serializable
enum class MatchingDifficulty(
    val label: String,
    val defaultThreshold: Float,
    val angleToleranceHint: String,
    val description: String
) {
    EASY(
        label = "Easy",
        defaultThreshold = 62.0f,
        angleToleranceHint = "Forgiving (±25° angle, wide lighting variation)",
        description = "Accepts broader framing & lighting shifts while rejecting unrelated rooms/objects."
    ),
    NORMAL(
        label = "Normal (Recommended)",
        defaultThreshold = 74.0f,
        angleToleranceHint = "Balanced (±15° angle, natural day/night lighting shift)",
        description = "Calibrated balance: verifies the exact washbasin/desk scene with realistic morning framing tolerance."
    ),
    HARD(
        label = "Strict",
        defaultThreshold = 84.0f,
        angleToleranceHint = "Precise (±8° angle, close framing alignment)",
        description = "Requires close alignment with the original angle, distance, and background layout."
    ),
    CUSTOM(
        label = "Custom Threshold",
        defaultThreshold = 76.0f,
        angleToleranceHint = "User-defined similarity score (50% - 95%)",
        description = "Fine-tune the exact composite visual similarity score required for dismissal."
    )
}

@Serializable
enum class VibrationPattern(val displayName: String, val timings: LongArray) {
    HEARTBEAT("Heartbeat Pulse", longArrayOf(0L, 180L, 120L, 280L, 700L)),
    CONTINUOUS_HEAVY("Relentless Heavy", longArrayOf(0L, 800L, 250L, 800L, 250L)),
    STACCATO_SIREN("Rapid Staccato", longArrayOf(0L, 150L, 100L, 150L, 100L, 150L, 400L)),
    GENTLE_WAVE("Gentle Wave", longArrayOf(0L, 300L, 600L, 450L, 800L))
}

@Serializable
enum class ThemeMode(val displayName: String) {
    SYSTEM("Follow System"),
    DARK_AMOLED("AMOLED Midnight Dark"),
    LIGHT("Daylight Clean")
}

/**
 * Rich multi-modal visual fingerprint extracted on-device for a reference or live photograph.
 * Combines:
 * 1. 128-D L2-normalized Neural Convolutional / LiteRT Scene Embedding (captures high-level texture & opponent-color filters)
 * 2. 192-D 4x4 Spatial Grid Illumination-Invariant Chromaticity + Luminance Histogram (captures spatial layout of colors)
 * 3. 128-D 4x4 Spatial Oriented Gradient (HOG/Sobel 8-bin direction) Descriptor (captures object geometry & scene structure)
 * 4. 64 Top ORB-style FAST Corner Keypoints with 64-bit Binary Brief Descriptors & normalized (x,y) coordinates (captures distinct local landmarks)
 * 5. 16x16 Multi-Scale Structural Luminance Map for SSIM & shift-tolerant alignment
 */
@Serializable
data class SceneFingerprint(
    val version: Int = 1,
    val neuralEmbedding: FloatArray,          // 128 floats, L2-normalized
    val spatialColorHistogram: FloatArray,    // 192 floats (4x4 grid x 12 bins HSV/Opponent)
    val spatialEdgeOrientation: FloatArray,   // 128 floats (4x4 grid x 8 orientation bins)
    val keypointCoords: FloatArray,           // Up to 64 keypoints * 2 (normalized x, y in 0..1)
    val keypointDescriptors: LongArray,       // Up to 64 keypoints * 64-bit binary patch descriptor
    val structuralGridLuminance: FloatArray,  // 256 floats (16x16 normalized luminance patch)
    val meanLuminance: Float,
    val contrastStd: Float,
    val edgeDensity: Float,
    val sha256Hex: String,
    val capturedTimestampMs: Long
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is SceneFingerprint) return false
        return sha256Hex == other.sha256Hex && capturedTimestampMs == other.capturedTimestampMs
    }

    override fun hashCode(): Int {
        return 31 * sha256Hex.hashCode() + capturedTimestampMs.hashCode()
    }
}

/**
 * Detailed breakdown returned by PhotoSimilarityEngine when comparing a live camera capture
 * against the stored reference SceneFingerprint.
 */
data class VerificationBreakdown(
    val overallScore: Float,                  // 0.0 .. 100.0 calibrated score
    val requiredThreshold: Float,             // 0.0 .. 100.0 target threshold
    val isMatched: Boolean,
    val neuralEmbeddingSimilarity: Float,     // 0.0 .. 100.0
    val spatialStructureSimilarity: Float,    // 0.0 .. 100.0 (HOG + shift-tolerant SSIM)
    val colorLayoutSimilarity: Float,         // 0.0 .. 100.0 (Illumination-normalized spatial color)
    val keypointGeometrySimilarity: Float,    // 0.0 .. 100.0 (ORB/Brief local landmark matches + spatial coherence)
    val livenessPassed: Boolean,
    val failureReason: String? = null,
    val userFeedbackMessage: String,
    val coachingTip: String
)

enum class VerificationStage(val statusText: String) {
    IDLE("Align the target scene inside the frame"),
    CAPTURING("Capturing live camera frame..."),
    ANALYZING("Analyzing photograph..."),
    COMPARING("Comparing with reference..."),
    MATCHED("Photograph matched."),
    NOT_MATCHED("Photograph not matched. Please try again.")
}
