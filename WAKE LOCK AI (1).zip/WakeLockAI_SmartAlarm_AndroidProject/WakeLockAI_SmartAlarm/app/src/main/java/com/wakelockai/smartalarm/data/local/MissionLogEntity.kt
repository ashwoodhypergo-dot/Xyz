package com.wakelockai.smartalarm.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.wakelockai.smartalarm.domain.model.MissionType

@Entity(tableName = "mission_logs")
data class MissionLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val alarmId: Long,
    val alarmLabel: String,
    val missionType: MissionType,
    val completedAtMillis: Long,
    val attemptsTaken: Int,
    val bestSimilarityScore: Float,
    val usedEmergencyFallback: Boolean = false
)
