package com.wakelockai.smartalarm.ui.navigation

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.wakelockai.smartalarm.WakeLockApplication
import com.wakelockai.smartalarm.alarm.AlarmService
import com.wakelockai.smartalarm.alarm.AlarmTimeCalculator
import com.wakelockai.smartalarm.data.local.AlarmEntity
import com.wakelockai.smartalarm.data.local.MissionLogEntity
import com.wakelockai.smartalarm.data.preferences.UserSettings
import com.wakelockai.smartalarm.domain.model.MatchingDifficulty
import com.wakelockai.smartalarm.domain.model.MissionType
import com.wakelockai.smartalarm.domain.model.SceneFingerprint
import com.wakelockai.smartalarm.domain.model.ThemeMode
import com.wakelockai.smartalarm.domain.model.VerificationBreakdown
import com.wakelockai.smartalarm.domain.model.VibrationPattern
import com.wakelockai.smartalarm.vision.ReferencePhotoStorage
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as WakeLockApplication
    private val repository = app.alarmRepository
    private val scheduler = app.alarmScheduler
    private val preferences = app.preferencesManager
    val photoStorage = app.photoStorage
    val featureExtractor = app.featureExtractor
    val similarityEngine = app.similarityEngine

    val alarms: StateFlow<List<AlarmEntity>> = repository.allAlarms.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val missionLogs: StateFlow<List<MissionLogEntity>> = repository.recentMissionLogs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val userSettings: StateFlow<UserSettings> = preferences.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UserSettings()
    )

    fun toggleAlarmEnabled(alarm: AlarmEntity, enabled: Boolean) {
        viewModelScope.launch {
            val nextTrigger = if (enabled) {
                AlarmTimeCalculator.computeNextTriggerMillis(
                    hour = alarm.hour,
                    minute = alarm.minute,
                    repeatDays = alarm.repeatDays
                )
            } else {
                0L
            }
            val updated = alarm.copy(
                isEnabled = enabled,
                currentSnoozeCount = 0,
                snoozedUntilMillis = null,
                nextTriggerTimeMillis = nextTrigger
            )
            repository.updateAlarm(updated)
            if (enabled) {
                scheduler.scheduleAlarm(updated, nextTrigger)
            } else {
                scheduler.cancelAlarm(updated.id)
            }
        }
    }

    fun saveOrUpdateAlarm(alarm: AlarmEntity, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val nextTrigger = if (alarm.isEnabled) {
                AlarmTimeCalculator.computeNextTriggerMillis(
                    hour = alarm.hour,
                    minute = alarm.minute,
                    repeatDays = alarm.repeatDays
                )
            } else {
                0L
            }
            val prepared = alarm.copy(
                currentSnoozeCount = 0,
                snoozedUntilMillis = null,
                nextTriggerTimeMillis = nextTrigger
            )
            val savedId = repository.saveAlarm(prepared)
            val finalEntity = prepared.copy(id = savedId)
            if (finalEntity.isEnabled) {
                scheduler.scheduleAlarm(finalEntity, nextTrigger)
            } else {
                scheduler.cancelAlarm(savedId)
            }
            onSaved(savedId)
        }
    }

    fun createQuickNapAlarm(minutesFromNow: Int) {
        viewModelScope.launch {
            val defaults = userSettings.value
            val triggerAt = System.currentTimeMillis() + minutesFromNow * 60_000L
            val zdt = Instant.ofEpochMilli(triggerAt).atZone(ZoneId.systemDefault())
            val napAlarm = AlarmEntity(
                hour = zdt.hour,
                minute = zdt.minute,
                label = "Quick Power Nap (${minutesFromNow}m)",
                isEnabled = true,
                repeatDays = emptySet(),
                ringtoneUri = defaults.defaultRingtoneUri,
                ringtoneTitle = defaults.defaultRingtoneTitle,
                alarmVolume = defaults.defaultAlarmVolume,
                vibrationEnabled = defaults.defaultVibrationEnabled,
                vibrationPattern = defaults.defaultVibrationPattern,
                snoozeEnabled = true,
                snoozeDurationMinutes = defaults.defaultSnoozeDurationMinutes,
                maxSnoozeCount = 1,
                missionType = MissionType.MATH,
                mathDifficultyLevel = 1,
                mathProblemCount = 2,
                nextTriggerTimeMillis = triggerAt
            )
            val id = repository.saveAlarm(napAlarm)
            scheduler.scheduleAlarm(napAlarm.copy(id = id), triggerAt)
        }
    }

    fun deleteAlarm(alarm: AlarmEntity) {
        viewModelScope.launch {
            scheduler.cancelAlarm(alarm.id)
            repository.deleteAlarm(alarm)
        }
    }

    fun triggerImmediateTestRing(alarm: AlarmEntity) {
        AlarmService.startAlarm(app, alarm.id)
    }

    suspend fun processAndSaveReferencePhoto(
        uri: Uri,
        previousPath: String?
    ): Result<Triple<ReferencePhotoStorage.SavedReferencePhoto, SceneFingerprint, String>> {
        return runCatching {
            val saved = photoStorage.saveGalleryReferencePhoto(uri, previousPath).getOrThrow()
            val fingerprint = featureExtractor.extractFingerprint(saved.bitmap)
            val serialized = featureExtractor.serializeFingerprint(fingerprint)
            Triple(saved, fingerprint, serialized)
        }
    }

    suspend fun evaluateLiveCaptureAgainstReference(
        referenceJson: String,
        liveBitmap: Bitmap,
        difficulty: MatchingDifficulty,
        customThreshold: Float
    ): VerificationBreakdown? {
        val refFp = featureExtractor.deserializeFingerprint(referenceJson) ?: return null
        val liveFp = featureExtractor.extractFingerprint(liveBitmap)
        return similarityEngine.verify(
            reference = refFp,
            liveCapture = liveFp,
            difficulty = difficulty,
            customThreshold = customThreshold,
            antiSpoofEnabled = userSettings.value.antiSpoofScreenCheckEnabled
        )
    }

    // Settings updates
    fun setUse24HourFormat(enabled: Boolean) {
        viewModelScope.launch { preferences.setUse24HourFormat(enabled) }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { preferences.setThemeMode(mode) }
    }

    fun setDefaultVolume(volume: Float) {
        viewModelScope.launch { preferences.setDefaultVolume(volume) }
    }

    fun setDefaultVibrationEnabled(enabled: Boolean) {
        viewModelScope.launch { preferences.setDefaultVibrationEnabled(enabled) }
    }

    fun setDefaultVibrationPattern(pattern: VibrationPattern) {
        viewModelScope.launch { preferences.setDefaultVibrationPattern(pattern) }
    }

    fun setDefaultSnoozeMinutes(minutes: Int) {
        viewModelScope.launch { preferences.setDefaultSnoozeMinutes(minutes) }
    }

    fun setDefaultMaxSnoozes(max: Int) {
        viewModelScope.launch { preferences.setDefaultMaxSnoozes(max) }
    }

    fun setDefaultDifficulty(difficulty: MatchingDifficulty) {
        viewModelScope.launch { preferences.setDefaultDifficulty(difficulty) }
    }

    fun setAntiSpoofScreenCheck(enabled: Boolean) {
        viewModelScope.launch { preferences.setAntiSpoofScreenCheck(enabled) }
    }

    fun setLockVolumeButtons(enabled: Boolean) {
        viewModelScope.launch { preferences.setLockVolumeButtons(enabled) }
    }

    fun wipeAllReferenceData(onComplete: (Int) -> Unit) {
        viewModelScope.launch {
            val count = repository.wipeAllReferencePhotosAndLogs()
            onComplete(count)
        }
    }
}
