package com.wakelockai.smartalarm.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID

/**
 * Manages secure, private internal storage for Alarm Photo Mission reference photographs.
 *
 * PRIVACY & SECURITY GUARANTEES:
 * - Reference photos are stored inside context.filesDir/reference_photos/ (private sandbox storage,
 *   inaccessible to other apps and excluded from MediaStore / public gallery indexing).
 * - Corrects EXIF orientation upon ingestion and normalizes resolution to max 1024px on the longest edge
 *   to keep storage footprint small and feature extraction fast across all device tiers.
 * - Computes SHA-256 cryptographic digest of the reference image so the live camera verifier can
 *   strictly prove that a reference image file was NEVER recycled or injected during alarm dismissal.
 */
class ReferencePhotoStorage(private val context: Context) {

    private val photoDir: File
        get() = File(context.filesDir, "reference_photos").apply {
            if (!exists()) mkdirs()
        }

    data class SavedReferencePhoto(
        val absolutePath: String,
        val sha256Hex: String,
        val bitmap: Bitmap
    )

    /**
     * Copies and normalizes a user-selected Gallery URI into private app storage.
     * ONLY permitted during Alarm creation/editing setup — never callable from AlarmRingingActivity.
     */
    suspend fun saveGalleryReferencePhoto(
        sourceUri: Uri,
        previousPathToDelete: String? = null
    ): Result<SavedReferencePhoto> = withContext(Dispatchers.IO) {
        runCatching {
            previousPathToDelete?.let { deletePhotoFile(it) }

            val decodedBitmap = decodeAndNormalizeUri(sourceUri)
                ?: throw IllegalArgumentException("Unable to decode selected image. Please choose a valid JPEG/PNG photo.")

            val fileName = "ref_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.jpg"
            val destFile = File(photoDir, fileName)

            val jpegBytes = ByteArrayOutputStream().use { bos ->
                decodedBitmap.compress(Bitmap.CompressFormat.JPEG, 92, bos)
                bos.toByteArray()
            }

            FileOutputStream(destFile).use { fos ->
                fos.write(jpegBytes)
                fos.flush()
            }

            val sha256 = computeSha256Hex(jpegBytes)
            SavedReferencePhoto(
                absolutePath = destFile.absolutePath,
                sha256Hex = sha256,
                bitmap = decodedBitmap
            )
        }
    }

    /**
     * Saves a bitmap directly as a reference photo (used when capturing a reference photo or running self-tests).
     */
    suspend fun saveBitmapAsReference(
        bitmap: Bitmap,
        previousPathToDelete: String? = null
    ): Result<SavedReferencePhoto> = withContext(Dispatchers.IO) {
        runCatching {
            previousPathToDelete?.let { deletePhotoFile(it) }
            val scaled = scaleDownMaxEdge(bitmap, 1024)
            val fileName = "ref_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.jpg"
            val destFile = File(photoDir, fileName)

            val jpegBytes = ByteArrayOutputStream().use { bos ->
                scaled.compress(Bitmap.CompressFormat.JPEG, 92, bos)
                bos.toByteArray()
            }

            FileOutputStream(destFile).use { fos ->
                fos.write(jpegBytes)
                fos.flush()
            }

            SavedReferencePhoto(
                absolutePath = destFile.absolutePath,
                sha256Hex = computeSha256Hex(jpegBytes),
                bitmap = scaled
            )
        }
    }

    suspend fun loadReferenceBitmap(path: String?): Bitmap? = withContext(Dispatchers.IO) {
        if (path.isNullOrBlank()) return@withContext null
        val file = File(path)
        if (!file.exists() || !file.canRead()) return@withContext null
        BitmapFactory.decodeFile(file.absolutePath)
    }

    fun deletePhotoFile(path: String?) {
        if (path.isNullOrBlank()) return
        runCatching {
            val file = File(path)
            if (file.exists() && file.parentFile?.canonicalPath == photoDir.canonicalPath) {
                file.delete()
            }
        }
    }

    /**
     * Deletes every saved reference photo in private storage and returns the count of removed files.
     */
    suspend fun deleteAllReferencePhotos(): Int = withContext(Dispatchers.IO) {
        val files = photoDir.listFiles() ?: return@withContext 0
        var deletedCount = 0
        for (file in files) {
            if (file.isFile && file.delete()) {
                deletedCount++
            }
        }
        deletedCount
    }

    fun getStorageStats(): Pair<Int, Long> {
        val files = photoDir.listFiles() ?: return 0 to 0L
        val count = files.count { it.isFile }
        val bytes = files.filter { it.isFile }.sumOf { it.length() }
        return count to bytes
    }

    private fun decodeAndNormalizeUri(uri: Uri): Bitmap? {
        val contentResolver = context.contentResolver

        // Step 1: Read bounds only
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { input ->
            BitmapFactory.decodeStream(input, null, options)
        }
        if (options.outWidth <= 0 || options.outHeight <= 0) return null

        // Step 2: Calculate sample size for max 1024px dimension
        var sampleSize = 1
        val maxDim = maxOf(options.outWidth, options.outHeight)
        while (maxDim / sampleSize > 1600) {
            sampleSize *= 2
        }

        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        val rawBitmap = contentResolver.openInputStream(uri)?.use { input ->
            BitmapFactory.decodeStream(input, null, decodeOptions)
        } ?: return null

        // Step 3: Read EXIF orientation
        val rotationDegrees = contentResolver.openInputStream(uri)?.use { input ->
            val exif = ExifInterface(input)
            when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } ?: 0f

        val rotatedBitmap = if (rotationDegrees != 0f) {
            val matrix = Matrix().apply { postRotate(rotationDegrees) }
            Bitmap.createBitmap(rawBitmap, 0, 0, rawBitmap.width, rawBitmap.height, matrix, true)
        } else {
            rawBitmap
        }

        return scaleDownMaxEdge(rotatedBitmap, 1024)
    }

    private fun scaleDownMaxEdge(bitmap: Bitmap, maxEdge: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= maxEdge && h <= maxEdge) return bitmap
        val ratio = maxEdge.toFloat() / maxOf(w, h).toFloat()
        val newW = (w * ratio).toInt().coerceAtLeast(64)
        val newH = (h * ratio).toInt().coerceAtLeast(64)
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }

    companion object {
        fun computeSha256Hex(bytes: ByteArray): String {
            val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
            return digest.joinToString("") { "%02x".format(it) }
        }

        fun computeBitmapSha256Hex(bitmap: Bitmap): String {
            val bos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, bos)
            return computeSha256Hex(bos.toByteArray())
        }
    }
}
