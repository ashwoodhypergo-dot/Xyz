package com.wakelockai.smartalarm.ui.theme

import androidx.compose.ui.graphics.Color

// Midnight Obsidian & Solar Coral Accent Palette (Next-Level Material 3 Dark/Light)
val MidnightBg = Color(0xFF0A0E14)
val MidnightSurface = Color(0xFF131924)
val MidnightSurfaceElevated = Color(0xFF1C2536)
val SolarCoral = Color(0xFFFF6B4A)
val SolarCoralLight = Color(0xFFFF8F73)
val ElectricCyan = Color(0xFF00E5FF)
val EmeraldSuccess = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val CrimsonDanger = Color(0xFFEF4444)

val DaylightBg = Color(0xFFF7F9FC)
val DaylightSurface = Color(0xFFFFFFFF)
val DaylightSurfaceVariant = Color(0xFFEEF2F8)
val DaylightPrimary = Color(0xFFE64A2E)
val DaylightSecondary = Color(0xFF007B8A)
