package com.wakelockai.smartalarm.ui.home

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.wakelockai.smartalarm.alarm.AlarmTimeCalculator
import com.wakelockai.smartalarm.data.local.AlarmEntity
import com.wakelockai.smartalarm.data.local.MissionLogEntity
import com.wakelockai.smartalarm.data.preferences.UserSettings
import com.wakelockai.smartalarm.domain.model.MissionType
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeDashboardScreen(
    alarms: List<AlarmEntity>,
    missionLogs: List<MissionLogEntity>,
    settings: UserSettings,
    onAddAlarmClick: () -> Unit,
    onEditAlarmClick: (AlarmEntity) -> Unit,
    onToggleAlarm: (AlarmEntity, Boolean) -> Unit,
    onQuickNapClick: (Int) -> Unit,
    onTestRingClick: (AlarmEntity) -> Unit,
    onDeleteAlarmClick: (AlarmEntity) -> Unit
) {
    val context = LocalContext.current
    var currentMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }

    // Live 1-second clock ticker
    LaunchedEffect(Unit) {
        while (true) {
            currentMillis = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val zdt = remember(currentMillis) {
        Instant.ofEpochMilli(currentMillis).atZone(ZoneId.systemDefault())
    }
    val (clockDigits, amPmText) = remember(zdt.hour, zdt.minute, settings.use24HourFormat) {
        AlarmTimeCalculator.formatTimeDisplay(zdt.hour, zdt.minute, settings.use24HourFormat)
    }
    val secondsString = remember(zdt.second) { String.format(Locale.US, ":%02d", zdt.second) }
    val dateFormatted = remember(zdt.toLocalDate()) {
        zdt.format(DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy", Locale.US))
    }

    val nextEnabledAlarm = remember(alarms, currentMillis) {
        alarms.filter { it.isEnabled }
            .minByOrNull { alarm ->
                if (alarm.nextTriggerTimeMillis > currentMillis) {
                    alarm.nextTriggerTimeMillis
                } else {
                    AlarmTimeCalculator.computeNextTriggerMillis(
                        alarm.hour,
                        alarm.minute,
                        alarm.repeatDays,
                        currentMillis
                    )
                }
            }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Hero Live Digital Clock & Offline Privacy Shield Badge
            item {
                HeroClockHeader(
                    clockDigits = clockDigits,
                    secondsString = secondsString,
                    amPmText = amPmText,
                    dateFormatted = dateFormatted,
                    nextAlarm = nextEnabledAlarm,
                    currentMillis = currentMillis
                )
            }

            // 2. Platform Permission & Reliability Readiness Banner
            item {
                PermissionReadinessBanner(context = context)
            }

            // 3. Quick Nap & Sleep Cycle Calculator Bar
            item {
                QuickNapAndSleepCycleCard(
                    currentMillis = currentMillis,
                    use24Hour = settings.use24HourFormat,
                    onQuickNapClick = onQuickNapClick
                )
            }

            // 4. Alarms Section Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Scheduled Alarms (${alarms.count { it.isEnabled }}/${alarms.size} active)",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    if (missionLogs.isNotEmpty()) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = "${missionLogs.size} Missions Completed",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // 5. Empty State or Alarm Cards
            if (alarms.isEmpty()) {
                item {
                    EmptyAlarmsCard(onAddAlarmClick = onAddAlarmClick)
                }
            } else {
                items(items = alarms, key = { it.id }) { alarm ->
                    AlarmCardItem(
                        alarm = alarm,
                        use24Hour = settings.use24HourFormat,
                        currentMillis = currentMillis,
                        onClick = { onEditAlarmClick(alarm) },
                        onToggle = { enabled -> onToggleAlarm(alarm, enabled) },
                        onTestRing = { onTestRingClick(alarm) },
                        onDelete = { onDeleteAlarmClick(alarm) }
                    )
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = onAddAlarmClick,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            icon = { Icon(Icons.Default.Add, contentDescription = "Add Alarm") },
            text = { Text("Add Smart Alarm", fontWeight = FontWeight.Bold) }
        )
    }
}

@Composable
private fun HeroClockHeader(
    clockDigits: String,
    secondsString: String,
    amPmText: String,
    dateFormatted: String,
    nextAlarm: AlarmEntity?,
    currentMillis: Long
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(50)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "100% Offline • On-Device Vision AI",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = clockDigits,
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = secondsString,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 6.dp, start = 2.dp)
                )
                if (amPmText.isNotEmpty()) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = amPmText,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }

            Text(
                text = dateFormatted,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = if (nextAlarm != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    if (nextAlarm != null) {
                        val targetMillis = if (nextAlarm.nextTriggerTimeMillis > currentMillis) {
                            nextAlarm.nextTriggerTimeMillis
                        } else {
                            AlarmTimeCalculator.computeNextTriggerMillis(
                                nextAlarm.hour,
                                nextAlarm.minute,
                                nextAlarm.repeatDays,
                                currentMillis
                            )
                        }
                        val countdown = AlarmTimeCalculator.formatCountdown(targetMillis, currentMillis)
                        Column {
                            Text(
                                text = "$countdown • ${nextAlarm.label}",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Mission: ${nextAlarm.missionType.displayName} (${nextAlarm.matchingDifficulty.label})",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        Text(
                            text = "No active alarms scheduled. Tap 'Add Smart Alarm' below.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionReadinessBanner(context: Context) {
    var hasCameraPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var hasNotificationPerm by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else true
        )
    }
    val alarmManager = context.getSystemService(AlarmManager::class.java)
    val canExactAlarm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        alarmManager?.canScheduleExactAlarms() ?: true
    } else true

    val powerManager = context.getSystemService(PowerManager::class.java)
    val isIgnoringBatteryOpt = powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: true

    val notificationManager = context.getSystemService(NotificationManager::class.java)
    val canFullScreenIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        notificationManager?.canUseFullScreenIntent() ?: true
    } else true

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        grants[Manifest.permission.CAMERA]?.let { hasCameraPerm = it }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            grants[Manifest.permission.POST_NOTIFICATIONS]?.let { hasNotificationPerm = it }
        }
    }

    if (hasCameraPerm && hasNotificationPerm && canExactAlarm && isIgnoringBatteryOpt && canFullScreenIntent) {
        return
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.85f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.WarningAmber,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onErrorContainer
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Action Needed for 100% Lock-Screen Reliability",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Grant Camera (for live Photo Mission), Notifications, Exact Alarm, and Unrestricted Battery so Android never blocks your morning alarm.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!hasCameraPerm || !hasNotificationPerm) {
                    Button(
                        onClick = {
                            val list = mutableListOf(Manifest.permission.CAMERA)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                list.add(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            permissionLauncher.launch(list.toTypedArray())
                        }
                    ) {
                        Text("Grant Camera & Alerts")
                    }
                }
                if (!canExactAlarm && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    FilledTonalButton(
                        onClick = {
                            runCatching {
                                context.startActivity(
                                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                        data = Uri.parse("package:${context.packageName}")
                                    }
                                )
                            }
                        }
                    ) {
                        Text("Exact Alarm")
                    }
                }
                if (!isIgnoringBatteryOpt) {
                    FilledTonalButton(
                        onClick = {
                            runCatching {
                                context.startActivity(
                                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                        data = Uri.parse("package:${context.packageName}")
                                    }
                                )
                            }
                        }
                    ) {
                        Text("Battery Unrestricted")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun QuickNapAndSleepCycleCard(
    currentMillis: Long,
    use24Hour: Boolean,
    onQuickNapClick: (Int) -> Unit
) {
    val suggestions = remember(currentMillis / 60_000L) {
        AlarmTimeCalculator.suggestSleepCycleWakeTimes(currentMillis)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Bedtime,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Quick Power Nap & 90-Min REM Sleep Cycles",
                    style = MaterialTheme.typography.titleMedium
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(15, 25, 45, 90).forEach { mins ->
                    AssistChip(
                        onClick = { onQuickNapClick(mins) },
                        label = { Text("+${mins}m Nap") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Bolt,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            val cycleSummary = suggestions.joinToString("  •  ") { (h, m, label) ->
                val (t, ap) = AlarmTimeCalculator.formatTimeDisplay(h, m, use24Hour)
                "$t $ap ($label)".trim()
            }
            Text(
                text = "If you sleep now, ideal REM wake windows: $cycleSummary",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun EmptyAlarmsCard(onAddAlarmClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.CameraAlt,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "No Smart Alarms Configured Yet",
                style = MaterialTheme.typography.titleLarge
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Create your first Photo Mission alarm. Register a reference photo of your bathroom sink, coffee maker, or study desk so you must physically get out of bed and snap a live photo to stop the alarm.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = onAddAlarmClick) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Create Photo Mission Alarm")
            }
        }
    }
}

@Composable
private fun AlarmCardItem(
    alarm: AlarmEntity,
    use24Hour: Boolean,
    currentMillis: Long,
    onClick: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onTestRing: () -> Unit,
    onDelete: () -> Unit
) {
    val (timeText, amPmText) = AlarmTimeCalculator.formatTimeDisplay(alarm.hour, alarm.minute, use24Hour)
    val repeatSummary = AlarmTimeCalculator.formatRepeatDaysSummary(alarm.repeatDays)
    val cardBg by animateColorAsState(
        targetValue = if (alarm.isEnabled) {
            MaterialTheme.colorScheme.surfaceVariant
        } else {
            MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
        },
        label = "AlarmCardBg"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = timeText,
                        style = MaterialTheme.typography.displayMedium,
                        color = if (alarm.isEnabled) {
                            MaterialTheme.colorScheme.onSurface
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        }
                    )
                    if (amPmText.isNotEmpty()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = amPmText,
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(bottom = 5.dp)
                        )
                    }
                }

                Switch(
                    checked = alarm.isEnabled,
                    onCheckedChange = onToggle
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "${alarm.label}  •  $repeatSummary",
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (alarm.isEnabled) {
                val target = if (alarm.nextTriggerTimeMillis > currentMillis) {
                    alarm.nextTriggerTimeMillis
                } else {
                    AlarmTimeCalculator.computeNextTriggerMillis(alarm.hour, alarm.minute, alarm.repeatDays, currentMillis)
                }
                Text(
                    text = AlarmTimeCalculator.formatCountdown(target, currentMillis),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mission Pill Badge
                Surface(
                    color = when (alarm.missionType) {
                        MissionType.PHOTO -> MaterialTheme.colorScheme.primaryContainer
                        MissionType.MATH -> MaterialTheme.colorScheme.secondaryContainer
                        MissionType.SHAKE -> MaterialTheme.colorScheme.tertiaryContainer
                        MissionType.NONE -> MaterialTheme.colorScheme.surface
                    },
                    shape = RoundedCornerShape(50)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = when (alarm.missionType) {
                                MissionType.PHOTO -> Icons.Default.CameraAlt
                                MissionType.MATH -> Icons.Default.Calculate
                                MissionType.SHAKE -> Icons.Default.Vibration
                                MissionType.NONE -> Icons.Default.CheckCircle
                            },
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        val badgeLabel = when (alarm.missionType) {
                            MissionType.PHOTO -> "Photo Mission (${alarm.matchingDifficulty.label})"
                            MissionType.MATH -> "Math (${alarm.mathProblemCount}x Lv.${alarm.mathDifficultyLevel})"
                            MissionType.SHAKE -> "Shake (${alarm.shakeTargetCount}x)"
                            MissionType.NONE -> "Standard Dismiss"
                        }
                        Text(
                            text = badgeLabel,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalButton(
                        onClick = onTestRing,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            Icons.Default.PlayArrow,
                            contentDescription = "Test Alarm Now",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Test Ring", style = MaterialTheme.typography.labelLarge)
                    }
                    IconButton(onClick = onDelete) {
                        Icon(
                            Icons.Default.DeleteOutline,
                            contentDescription = "Delete Alarm",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
