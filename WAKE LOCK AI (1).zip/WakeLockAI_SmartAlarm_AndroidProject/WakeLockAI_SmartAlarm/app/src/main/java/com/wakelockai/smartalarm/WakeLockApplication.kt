package com.wakelockai.smartalarm

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.media.AudioAttributes
import android.os.Build
import com.wakelockai.smartalarm.alarm.AlarmScheduler
import com.wakelockai.smartalarm.data.local.AppDatabase
import com.wakelockai.smartalarm.data.preferences.PreferencesManager
import com.wakelockai.smartalarm.data.repository.AlarmRepository
import com.wakelockai.smartalarm.vision.PhotoSimilarityEngine
import com.wakelockai.smartalarm.vision.ReferencePhotoStorage
import com.wakelockai.smartalarm.vision.SceneFeatureExtractor

class WakeLockApplication : Application() {

    lateinit var database: AppDatabase
        private set
    lateinit var preferencesManager: PreferencesManager
        private set
    lateinit var photoStorage: ReferencePhotoStorage
        private set
    lateinit var featureExtractor: SceneFeatureExtractor
        private set
    lateinit var similarityEngine: PhotoSimilarityEngine
        private set
    lateinit var alarmRepository: AlarmRepository
        private set
    lateinit var alarmScheduler: AlarmScheduler
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        preferencesManager = PreferencesManager(this)
        photoStorage = ReferencePhotoStorage(this)
        featureExtractor = SceneFeatureExtractor(this)
        similarityEngine = PhotoSimilarityEngine()
        alarmRepository = AlarmRepository(database.alarmDao(), photoStorage)
        alarmScheduler = AlarmScheduler(this)

        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java) ?: return

            val alarmChannel = NotificationChannel(
                CHANNEL_ACTIVE_ALARM,
                getString(R.string.alarm_notification_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.alarm_notification_channel_desc)
                setBypassDnd(true)
                enableVibration(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                // Audio is played directly by AlarmService on STREAM_ALARM for fine-grained progressive volume control
                setSound(null, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            }

            val wakeUpCheckChannel = NotificationChannel(
                CHANNEL_WAKEUP_CHECK,
                getString(R.string.wakeup_check_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.wakeup_check_channel_desc)
                setBypassDnd(true)
                enableVibration(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            nm.createNotificationChannels(listOf(alarmChannel, wakeUpCheckChannel))
        }
    }

    companion object {
        const val CHANNEL_ACTIVE_ALARM = "wakelock_active_alarm_channel"
        const val CHANNEL_WAKEUP_CHECK = "wakelock_wakeup_check_channel"
    }
}
