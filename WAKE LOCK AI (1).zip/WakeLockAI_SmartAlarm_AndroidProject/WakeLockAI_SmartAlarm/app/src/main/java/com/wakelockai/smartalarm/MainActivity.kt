package com.wakelockai.smartalarm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.wakelockai.smartalarm.data.local.AlarmEntity
import com.wakelockai.smartalarm.ui.editor.AlarmEditorScreen
import com.wakelockai.smartalarm.ui.home.HomeDashboardScreen
import com.wakelockai.smartalarm.ui.navigation.MainViewModel
import com.wakelockai.smartalarm.ui.settings.SettingsAndDiagnosticsScreen
import com.wakelockai.smartalarm.ui.theme.WakeLockAITheme

private enum class AppTab(val label: String) {
    DASHBOARD("Alarms"),
    VISION_LAB("AI Vision Lab"),
    SETTINGS("Settings & Health")
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settings by viewModel.userSettings.collectAsState()
            WakeLockAITheme(themeMode = settings.themeMode) {
                WakeLockRootApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
private fun WakeLockRootApp(viewModel: MainViewModel) {
    val alarms by viewModel.alarms.collectAsState()
    val settings by viewModel.userSettings.collectAsState()
    val missionLogs by viewModel.missionLogs.collectAsState()

    var currentTab by remember { mutableStateOf(AppTab.DASHBOARD) }
    var editingAlarm by remember { mutableStateOf<AlarmEntity?>(null) }
    var isCreatingNewAlarm by remember { mutableStateOf(false) }

    if (isCreatingNewAlarm || editingAlarm != null) {
        val initialAlarm = editingAlarm ?: AlarmEntity(
            hour = 7,
            minute = 0,
            label = "Morning Wake Up",
            ringtoneUri = settings.defaultRingtoneUri,
            ringtoneTitle = settings.defaultRingtoneTitle,
            alarmVolume = settings.defaultAlarmVolume,
            vibrationEnabled = settings.defaultVibrationEnabled,
            vibrationPattern = settings.defaultVibrationPattern,
            snoozeDurationMinutes = settings.defaultSnoozeDurationMinutes,
            maxSnoozeCount = settings.defaultMaxSnoozes,
            matchingDifficulty = settings.defaultMatchingDifficulty,
            customSimilarityThreshold = settings.defaultMatchingDifficulty.defaultThreshold
        )

        AlarmEditorScreen(
            initialAlarm = initialAlarm,
            isNewAlarm = isCreatingNewAlarm,
            use24Hour = settings.use24HourFormat,
            viewModel = viewModel,
            onDismiss = {
                editingAlarm = null
                isCreatingNewAlarm = false
            },
            onSave = { updatedAlarm ->
                viewModel.saveOrUpdateAlarm(updatedAlarm) {
                    editingAlarm = null
                    isCreatingNewAlarm = false
                }
            },
            onDelete = { toDelete ->
                viewModel.deleteAlarm(toDelete)
                editingAlarm = null
                isCreatingNewAlarm = false
            }
        )
        return
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentTab == AppTab.DASHBOARD,
                    onClick = { currentTab = AppTab.DASHBOARD },
                    icon = { Icon(Icons.Default.Alarm, contentDescription = "Alarms") },
                    label = { Text("Alarms") }
                )
                NavigationBarItem(
                    selected = currentTab == AppTab.VISION_LAB,
                    onClick = { currentTab = AppTab.VISION_LAB },
                    icon = { Icon(Icons.Default.Analytics, contentDescription = "AI Vision Lab") },
                    label = { Text("Photo AI Lab") }
                )
                NavigationBarItem(
                    selected = currentTab == AppTab.SETTINGS,
                    onClick = { currentTab = AppTab.SETTINGS },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") }
                )
            }
        }
    ) { innerPadding ->
        AnimatedContent(
            targetState = currentTab,
            modifier = Modifier.padding(innerPadding),
            label = "TabTransition"
        ) { tab ->
            when (tab) {
                AppTab.DASHBOARD -> {
                    HomeDashboardScreen(
                        alarms = alarms,
                        missionLogs = missionLogs,
                        settings = settings,
                        onAddAlarmClick = { isCreatingNewAlarm = true },
                        onEditAlarmClick = { alarm -> editingAlarm = alarm },
                        onToggleAlarm = { alarm, enabled ->
                            viewModel.toggleAlarmEnabled(alarm, enabled)
                        },
                        onQuickNapClick = { mins ->
                            viewModel.createQuickNapAlarm(mins)
                        },
                        onTestRingClick = { alarm ->
                            viewModel.triggerImmediateTestRing(alarm)
                        },
                        onDeleteAlarmClick = { alarm ->
                            viewModel.deleteAlarm(alarm)
                        }
                    )
                }

                AppTab.VISION_LAB -> {
                    SettingsAndDiagnosticsScreen(
                        viewModel = viewModel,
                        settings = settings,
                        initialSection = "VISION_LAB"
                    )
                }

                AppTab.SETTINGS -> {
                    SettingsAndDiagnosticsScreen(
                        viewModel = viewModel,
                        settings = settings,
                        initialSection = "SETTINGS"
                    )
                }
            }
        }
    }
}
