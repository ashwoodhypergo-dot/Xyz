package com.wakelockai.smartalarm.data.repository

import com.wakelockai.smartalarm.data.local.AlarmDao
import com.wakelockai.smartalarm.data.local.AlarmEntity
import com.wakelockai.smartalarm.data.local.MissionLogEntity
import com.wakelockai.smartalarm.vision.ReferencePhotoStorage
import kotlinx.coroutines.flow.Flow

class AlarmRepository(
    private val alarmDao: AlarmDao,
    private val photoStorage: ReferencePhotoStorage
) {
    val allAlarms: Flow<List<AlarmEntity>> = alarmDao.observeAllAlarms()
    val recentMissionLogs: Flow<List<MissionLogEntity>> = alarmDao.observeRecentMissionLogs()

    suspend fun getAllAlarmsOnce(): List<AlarmEntity> = alarmDao.getAllAlarmsOnce()

    suspend fun getEnabledAlarmsOnce(): List<AlarmEntity> = alarmDao.getEnabledAlarmsOnce()

    suspend fun getAlarmById(id: Long): AlarmEntity? = alarmDao.getAlarmById(id)

    fun observeAlarmById(id: Long): Flow<AlarmEntity?> = alarmDao.observeAlarmById(id)

    suspend fun saveAlarm(alarm: AlarmEntity): Long {
        return alarmDao.insertAlarm(alarm)
    }

    suspend fun updateAlarm(alarm: AlarmEntity) {
        alarmDao.updateAlarm(alarm)
    }

    suspend fun deleteAlarm(alarm: AlarmEntity) {
        alarm.referencePhotoPath?.let { photoStorage.deletePhotoFile(it) }
        alarmDao.deleteAlarm(alarm)
    }

    suspend fun recordMissionCompletion(log: MissionLogEntity) {
        alarmDao.insertMissionLog(log)
    }

    suspend fun wipeAllReferencePhotosAndLogs(): Int {
        val removedFiles = photoStorage.deleteAllReferencePhotos()
        alarmDao.clearAllReferencePhotosInDb()
        alarmDao.clearMissionLogs()
        return removedFiles
    }
}
