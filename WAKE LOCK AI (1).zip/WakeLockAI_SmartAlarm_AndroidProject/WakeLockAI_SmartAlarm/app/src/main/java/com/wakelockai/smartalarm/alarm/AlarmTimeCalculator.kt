package com.wakelockai.smartalarm.alarm

import java.time.DayOfWeek
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale

/**
 * Pure, deterministic time calculation engine for one-time, repeating weekday, and snoozed alarms.
 * Handles DST transitions, timezone changes, and manual clock adjustments cleanly via java.time.ZonedDateTime.
 */
object AlarmTimeCalculator {

    /**
     * Computes the exact next epoch millisecond when an alarm at (hour, minute) should ring.
     *
     * @param hour 0..23
     * @param minute 0..59
     * @param repeatDays Set of ISO-8601 day numbers (1 = Monday .. 7 = Sunday). Empty set = one-time alarm.
     * @param nowMillis Current reference epoch time in milliseconds.
     * @param zoneId Current device timezone.
     */
    fun computeNextTriggerMillis(
        hour: Int,
        minute: Int,
        repeatDays: Set<Int>,
        nowMillis: Long = System.currentTimeMillis(),
        zoneId: ZoneId = ZoneId.systemDefault()
    ): Long {
        val nowZdt = Instant.ofEpochMilli(nowMillis).atZone(zoneId)
        var candidate = nowZdt
            .withHour(hour.coerceIn(0, 23))
            .withMinute(minute.coerceIn(0, 59))
            .withSecond(0)
            .withNano(0)

        // If candidate is in the past or within the current second, move to at least tomorrow
        if (!candidate.isAfter(nowZdt)) {
            candidate = candidate.plusDays(1)
        }

        if (repeatDays.isEmpty()) {
            return candidate.toInstant().toEpochMilli()
        }

        // Advance day-by-day up to 7 days until we hit a selected DayOfWeek (1 = Monday .. 7 = Sunday)
        for (offset in 0..7) {
            val checkDate = candidate.plusDays(offset.toLong())
            val dayNumber = checkDate.dayOfWeek.value // 1..7
            if (repeatDays.contains(dayNumber)) {
                return checkDate.toInstant().toEpochMilli()
            }
        }

        return candidate.toInstant().toEpochMilli()
    }

    /**
     * Returns a concise human-readable countdown string (e.g., "Rings in 7h 42m" or "Rings in Less than a minute").
     */
    fun formatCountdown(
        targetMillis: Long,
        nowMillis: Long = System.currentTimeMillis()
    ): String {
        val diffMillis = (targetMillis - nowMillis).coerceAtLeast(0L)
        val totalMinutes = diffMillis / 60_000L
        if (totalMinutes < 1L) {
            return "Rings in less than 1 minute"
        }
        val days = totalMinutes / (24 * 60)
        val hours = (totalMinutes % (24 * 60)) / 60
        val minutes = totalMinutes % 60

        return buildString {
            append("Rings in ")
            if (days > 0) append("${days}d ")
            if (hours > 0) append("${hours}h ")
            if (minutes > 0 || (days == 0L && hours == 0L)) append("${minutes}m")
        }.trim()
    }

    /**
     * Formats hour and minute into 12-hour (with AM/PM) or 24-hour display pair: (timePart, amPmPart).
     */
    fun formatTimeDisplay(hour: Int, minute: Int, use24Hour: Boolean): Pair<String, String> {
        return if (use24Hour) {
            String.format(Locale.US, "%02d:%02d", hour, minute) to ""
        } else {
            val amPm = if (hour < 12) "AM" else "PM"
            val h12 = when {
                hour == 0 -> 12
                hour > 12 -> hour - 12
                else -> hour
            }
            String.format(Locale.US, "%02d:%02d", h12, minute) to amPm
        }
    }

    /**
     * Formats selected repeat days (1=Mon .. 7=Sun) into a clean label ("Every day", "Weekdays", "Weekends", "Mon, Wed, Fri", or "One-time").
     */
    fun formatRepeatDaysSummary(repeatDays: Set<Int>): String {
        if (repeatDays.isEmpty()) return "One-time alarm"
        if (repeatDays.size == 7) return "Every day"
        if (repeatDays == setOf(1, 2, 3, 4, 5)) return "Weekdays (Mon–Fri)"
        if (repeatDays == setOf(6, 7)) return "Weekends (Sat–Sun)"

        val shortNames = mapOf(
            1 to "Mon",
            2 to "Tue",
            3 to "Wed",
            4 to "Thu",
            5 to "Fri",
            6 to "Sat",
            7 to "Sun"
        )
        return repeatDays.sorted().mapNotNull { shortNames[it] }.joinToString(", ")
    }

    /**
     * Suggests optimal 90-minute REM sleep cycle wake-up times starting from now (including 14 minutes average sleep onset).
     */
    fun suggestSleepCycleWakeTimes(
        nowMillis: Long = System.currentTimeMillis(),
        zoneId: ZoneId = ZoneId.systemDefault()
    ): List<Triple<Int, Int, String>> {
        val base = Instant.ofEpochMilli(nowMillis).atZone(zoneId).plusMinutes(14)
        // 4 cycles (6h), 5 cycles (7.5h), 6 cycles (9h)
        return listOf(4, 5, 6).map { cycles ->
            val target = base.plusMinutes((cycles * 90).toLong())
            val hoursFloat = cycles * 1.5
            val label = "${cycles} cycles (${if (hoursFloat % 1.0 == 0.0) "${hoursFloat.toInt()}h" else "${hoursFloat}h"} sleep)"
            Triple(target.hour, target.minute, label)
        }
    }
}
