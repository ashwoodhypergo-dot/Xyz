package com.wakelockai.smartalarm.alarm

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.wakelockai.smartalarm.R
import com.wakelockai.smartalarm.WakeLockApplication
import com.wakelockai.smartalarm.data.local.AlarmEntity
import com.wakelockai.smartalarm.domain.model.VibrationPattern
import com.wakelockai.smartalarm.ui.ringing.AlarmRingingActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Unstoppable Foreground Service responsible for:
 * 1. Holding a partial CPU WakeLock so the alarm never cuts out if the screen dims.
 * 2. Playing the configured alarm ringtone on AudioManager.STREAM_ALARM with progressive volume ramp-up.
 * 3. Enforcing system alarm volume and preventing silent-mode muting.
 * 4. Driving the custom VibrationEffect pattern.
 * 5. Managing simultaneous/queued alarms if multiple alarms trigger while one is already ringing.
 * 6. Presenting a high-priority Category_ALARM Full-Screen Intent notification that breaks through
 *    the lock screen and launches AlarmRingingActivity.
 */
class AlarmService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wakeLock: PowerManager.WakeLock? = null
    private var mediaPlayer: MediaPlayer? = null
    private var volumeRampJob: Job? = null
    private var flashlightStrobeJob: Job? = null
    private var audioFocusRequest: AudioFocusRequest? = null

    private val queuedAlarmIds = ArrayDeque<Long>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_ALARM -> {
                val alarmId = intent.getLongExtra(AlarmReceiver.EXTRA_ALARM_ID, -1L)
                if (alarmId != -1L) {
                    handleStartAlarm(alarmId)
                }
            }
            ACTION_PAUSE_AUDIO_FOR_CAMERA -> {
                // Temporarily lower volume slightly during live camera capture so the user isn't panicked,
                // but automatically resumes full volume after 25 seconds if mission isn't completed!
                temporarilyAttenuateVolumeForMission()
            }
            ACTION_STOP_CURRENT_ALARM -> {
                stopCurrentAndAdvanceQueue()
            }
        }
        return START_STICKY
    }

    private fun handleStartAlarm(alarmId: Long) {
        val currentActive = _activeAlarmState.value
        if (currentActive != null && currentActive.id != alarmId) {
            if (!queuedAlarmIds.contains(alarmId)) {
                queuedAlarmIds.addLast(alarmId)
            }
            return
        }

        acquireWakeLock()

        serviceScope.launch {
            val app = application as WakeLockApplication
            val alarm = app.alarmRepository.getAlarmById(alarmId) ?: run {
                stopSelfIfIdle()
                return@launch
            }

            _activeAlarmState.value = alarm

            val notification = buildFullScreenAlarmNotification(alarm)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }

            startAlarmAudio(alarm)
            if (alarm.vibrationEnabled) {
                startAlarmVibration(alarm.vibrationPattern)
            }
            if (alarm.flashlightStrobeEnabled) {
                startFlashlightStrobe()
            }

            // Also explicitly launch the full-screen activity when permitted by the platform
            val fullScreenIntent = Intent(this@AlarmService, AlarmRingingActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_NO_USER_ACTION
                )
                putExtra(AlarmReceiver.EXTRA_ALARM_ID, alarm.id)
            }
            runCatching { startActivity(fullScreenIntent) }
        }
    }

    private fun buildFullScreenAlarmNotification(alarm: AlarmEntity): Notification {
        val fullScreenIntent = Intent(this, AlarmRingingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, alarm.id)
        }
        val fullScreenPi = PendingIntent.getActivity(
            this,
            alarm.id.toInt() + 50_000,
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val missionBadge = when (alarm.missionType.name) {
            "PHOTO" -> "Photo Mission Required"
            "MATH" -> "Math Mission Required"
            "SHAKE" -> "Shake Mission Required"
            else -> "Tap to open alarm"
        }

        return NotificationCompat.Builder(this, WakeLockApplication.CHANNEL_ACTIVE_ALARM)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(alarm.label.ifBlank { "Smart Alarm Ringing" })
            .setContentText("$missionBadge • Cannot be swiped away")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(fullScreenPi)
            .setFullScreenIntent(fullScreenPi, true)
            .build()
    }

    private fun startAlarmAudio(alarm: AlarmEntity) {
        stopAudioAndVibration()

        val audioManager = getSystemService(AudioManager::class.java)
        if (audioManager != null) {
            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM).coerceAtLeast(1)
            val targetStreamVol = (maxVol * alarm.alarmVolume.coerceIn(0.15f, 1.0f)).toInt().coerceAtLeast(1)
            runCatching {
                audioManager.setStreamVolume(AudioManager.STREAM_ALARM, targetStreamVol, 0)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .build()
                audioFocusRequest = req
                audioManager.requestAudioFocus(req)
            }
        }

        val ringtoneUri: Uri = when {
            alarm.ringtoneUri.isBlank() || alarm.ringtoneUri == "DEFAULT_ALARM" ->
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            else -> Uri.parse(alarm.ringtoneUri)
        }

        val player = MediaPlayer()
        try {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            try {
                player.setDataSource(this, ringtoneUri)
            } catch (_: Exception) {
                val fallback = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                if (fallback != null) player.setDataSource(this, fallback)
            }
            player.isLooping = true
            player.prepare()

            val rampSeconds = alarm.progressiveVolumeRampSeconds.coerceIn(0, 60)
            if (rampSeconds == 0) {
                player.setVolume(1.0f, 1.0f)
                player.start()
            } else {
                player.setVolume(0.12f, 0.12f)
                player.start()
                volumeRampJob = serviceScope.launch {
                    val steps = rampSeconds * 2
                    for (step in 1..steps) {
                        delay(500L)
                        val fraction = (step.toFloat() / steps.toFloat()).coerceIn(0.12f, 1.0f)
                        runCatching { player.setVolume(fraction, fraction) }
                    }
                }
            }
            mediaPlayer = player
        } catch (_: Exception) {
            runCatching { player.release() }
        }
    }

    private fun temporarilyAttenuateVolumeForMission() {
        val player = mediaPlayer ?: return
        volumeRampJob?.cancel()
        volumeRampJob = serviceScope.launch {
            runCatching { player.setVolume(0.30f, 0.30f) }
            delay(25_000L)
            // Restore full alarm volume if user hasn't completed the Photo Mission within 25 seconds
            runCatching { player.setVolume(1.0f, 1.0f) }
        }
    }

    private fun startAlarmVibration(pattern: VibrationPattern) {
        val vibrator = getVibrator() ?: return
        if (!vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val effect = VibrationEffect.createWaveform(pattern.timings, 0)
            vibrator.vibrate(effect)
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(pattern.timings, 0)
        }
    }

    private fun startFlashlightStrobe() {
        flashlightStrobeJob?.cancel()
        flashlightStrobeJob = serviceScope.launch(Dispatchers.IO) {
            val cm = getSystemService(CameraManager::class.java) ?: return@launch
            val cameraId = runCatching {
                cm.cameraIdList.firstOrNull { id ->
                    cm.getCameraCharacteristics(id)
                        .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
            }.getOrNull() ?: return@launch

            var torchOn = false
            try {
                while (isActive) {
                    // Only strobe when camera mission is not actively using the camera session
                    if (!_isCameraSessionActive.value) {
                        torchOn = !torchOn
                        runCatching { cm.setTorchMode(cameraId, torchOn) }
                    }
                    delay(600L)
                }
            } finally {
                runCatching { cm.setTorchMode(cameraId, false) }
            }
        }
    }

    private fun stopCurrentAndAdvanceQueue() {
        stopAudioAndVibration()
        _activeAlarmState.value = null

        val nextAlarmId = queuedAlarmIds.removeFirstOrNull()
        if (nextAlarmId != null) {
            handleStartAlarm(nextAlarmId)
        } else {
            stopSelfIfIdle()
        }
    }

    private fun stopAudioAndVibration() {
        volumeRampJob?.cancel()
        volumeRampJob = null

        flashlightStrobeJob?.cancel()
        flashlightStrobeJob = null

        mediaPlayer?.let { player ->
            runCatching {
                if (player.isPlaying) player.stop()
                player.release()
            }
        }
        mediaPlayer = null

        runCatching { getVibrator()?.cancel() }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { req ->
                runCatching { getSystemService(AudioManager::class.java)?.abandonAudioFocusRequest(req) }
            }
            audioFocusRequest = null
        }
    }

    private fun stopSelfIfIdle() {
        releaseWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java) ?: return
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "WakeLockAI::SmartAlarmRingingWakeLock"
        ).apply {
            acquire(30 * 60 * 1000L) // Max 30 minutes safety cap
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { wl ->
            if (wl.isHeld) {
                runCatching { wl.release() }
            }
        }
        wakeLock = null
    }

    private fun getVibrator(): Vibrator? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Vibrator::class.java)
        }
    }

    override fun onDestroy() {
        stopAudioAndVibration()
        releaseWakeLock()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val NOTIFICATION_ID = 9001
        const val ACTION_START_ALARM = "com.wakelockai.smartalarm.ACTION_START_ALARM_SERVICE"
        const val ACTION_PAUSE_AUDIO_FOR_CAMERA = "com.wakelockai.smartalarm.ACTION_PAUSE_AUDIO_FOR_CAMERA"
        const val ACTION_STOP_CURRENT_ALARM = "com.wakelockai.smartalarm.ACTION_STOP_CURRENT_ALARM"

        private val _activeAlarmState = MutableStateFlow<AlarmEntity?>(null)
        val activeAlarmState: StateFlow<AlarmEntity?> = _activeAlarmState.asStateFlow()

        private val _isCameraSessionActive = MutableStateFlow(false)
        fun setCameraSessionActive(active: Boolean) {
            _isCameraSessionActive.value = active
        }

        fun startAlarm(context: Context, alarmId: Long) {
            val intent = Intent(context, AlarmService::class.java).apply {
                action = ACTION_START_ALARM
                putExtra(AlarmReceiver.EXTRA_ALARM_ID, alarmId)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun attenuateAudioForCamera(context: Context) {
            val intent = Intent(context, AlarmService::class.java).apply {
                action = ACTION_PAUSE_AUDIO_FOR_CAMERA
            }
            context.startService(intent)
        }

        fun stopActiveAlarm(context: Context) {
            val intent = Intent(context, AlarmService::class.java).apply {
                action = ACTION_STOP_CURRENT_ALARM
            }
            context.startService(intent)
        }
    }
}
