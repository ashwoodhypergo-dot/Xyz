package com.wakelockai.smartalarm

import com.wakelockai.smartalarm.alarm.AlarmTimeCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class AlarmTimeCalculatorTest {

    @Test
    fun `one-time alarm later today schedules for today`() {
        val zone = ZoneId.of("UTC")
        val now = ZonedDateTime.of(2026, 11, 4, 6, 30, 0, 0, zone).toInstant().toEpochMilli()
        val trigger = AlarmTimeCalculator.computeNextTriggerMillis(
            hour = 7,
            minute = 15,
            repeatDays = emptySet(),
            nowMillis = now,
            zoneId = zone
        )
        val triggerZdt = java.time.Instant.ofEpochMilli(trigger).atZone(zone)
        assertEquals(2026, triggerZdt.year)
        assertEquals(11, triggerZdt.monthValue)
        assertEquals(4, triggerZdt.dayOfMonth)
        assertEquals(7, triggerZdt.hour)
        assertEquals(15, triggerZdt.minute)
    }

    @Test
    fun `one-time alarm earlier than current time schedules for tomorrow`() {
        val zone = ZoneId.of("UTC")
        val now = ZonedDateTime.of(2026, 11, 4, 8, 0, 0, 0, zone).toInstant().toEpochMilli()
        val trigger = AlarmTimeCalculator.computeNextTriggerMillis(
            hour = 7,
            minute = 0,
            repeatDays = emptySet(),
            nowMillis = now,
            zoneId = zone
        )
        val triggerZdt = java.time.Instant.ofEpochMilli(trigger).atZone(zone)
        assertEquals(5, triggerZdt.dayOfMonth)
        assertEquals(7, triggerZdt.hour)
    }

    @Test
    fun `repeating weekday alarm skips non-selected days accurately`() {
        val zone = ZoneId.of("UTC")
        // 2026-11-04 is a Wednesday (dayOfWeek = 3). Select Friday (5) only.
        val now = ZonedDateTime.of(2026, 11, 4, 9, 0, 0, 0, zone).toInstant().toEpochMilli()
        val trigger = AlarmTimeCalculator.computeNextTriggerMillis(
            hour = 6,
            minute = 45,
            repeatDays = setOf(5),
            nowMillis = now,
            zoneId = zone
        )
        val triggerZdt = java.time.Instant.ofEpochMilli(trigger).atZone(zone)
        assertEquals(6, triggerZdt.dayOfMonth) // Friday Nov 6
        assertEquals(5, triggerZdt.dayOfWeek.value)
        assertEquals(6, triggerZdt.hour)
        assertEquals(45, triggerZdt.minute)
    }

    @Test
    fun `sleep cycle suggestions return three valid 90-minute cycle windows`() {
        val zone = ZoneId.of("UTC")
        val now = ZonedDateTime.of(2026, 11, 4, 22, 0, 0, 0, zone).toInstant().toEpochMilli()
        val cycles = AlarmTimeCalculator.suggestSleepCycleWakeTimes(now, zone)
        assertEquals(3, cycles.size)
        assertTrue(cycles[0].third.contains("4 cycles"))
        assertTrue(cycles[1].third.contains("5 cycles"))
        assertTrue(cycles[2].third.contains("6 cycles"))
    }
}
