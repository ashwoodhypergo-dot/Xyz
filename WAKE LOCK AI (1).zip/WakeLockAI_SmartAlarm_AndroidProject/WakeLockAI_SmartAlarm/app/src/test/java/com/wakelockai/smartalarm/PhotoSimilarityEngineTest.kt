package com.wakelockai.smartalarm

import com.wakelockai.smartalarm.domain.model.MatchingDifficulty
import com.wakelockai.smartalarm.domain.model.SceneFingerprint
import com.wakelockai.smartalarm.vision.PhotoSimilarityEngine
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class PhotoSimilarityEngineTest {

    private val engine = PhotoSimilarityEngine()

    private fun createMockFingerprint(
        seedAngle: Float,
        gridShift: Int = 0,
        sha256: String = "hash_$seedAngle",
        lumMean: Float = 0.52f
    ): SceneFingerprint {
        val neural = FloatArray(128) { idx -> cos(seedAngle + idx * 0.11f) }
        val color = FloatArray(192) { idx -> sin(seedAngle + ((idx + gridShift) % 192) * 0.07f) + 1.1f }
        val edge = FloatArray(128) { idx -> cos(seedAngle * 0.8f + ((idx + gridShift) % 128) * 0.09f) + 1.1f }
        val grid = FloatArray(256) { idx ->
            val shifted = (idx + gridShift + 256) % 256
            0.5f + 0.35f * sin(seedAngle + shifted * 0.05f)
        }
        val kpCoords = FloatArray(32 * 2) { idx -> ((idx % 32) / 32f + gridShift * 0.01f).coerceIn(0.05f, 0.95f) }
        val kpDesc = LongArray(32) { idx ->
            if (seedAngle < 1.0f) (0x123456789ABCDEF0L xor idx.toLong())
            else (0xFEDCBA9876543210UL.toLong() xor (idx * 999L))
        }

        return SceneFingerprint(
            neuralEmbedding = normalize(neural),
            spatialColorHistogram = normalize(color),
            spatialEdgeOrientation = normalize(edge),
            keypointCoords = kpCoords,
            keypointDescriptors = kpDesc,
            structuralGridLuminance = grid,
            meanLuminance = lumMean,
            contrastStd = 0.18f,
            edgeDensity = 0.24f,
            sha256Hex = sha256,
            capturedTimestampMs = 1700000000000L
        )
    }

    private fun normalize(v: FloatArray): FloatArray {
        var s = 0f
        for (x in v) s += x * x
        val n = sqrt(s).coerceAtLeast(1e-6f)
        return FloatArray(v.size) { v[it] / n }
    }

    @Test
    fun `exact duplicate SHA256 reference image is strictly rejected`() {
        val ref = createMockFingerprint(seedAngle = 0.2f, sha256 = "same_exact_file_hash")
        val duplicate = createMockFingerprint(seedAngle = 0.2f, sha256 = "same_exact_file_hash")

        val result = engine.verify(ref, duplicate, MatchingDifficulty.NORMAL)
        assertFalse("Duplicate reference hash must never pass live verification", result.isMatched)
        assertFalse(result.livenessPassed)
    }

    @Test
    fun `same scene with slight angle and lighting variation is accepted`() {
        val ref = createMockFingerprint(seedAngle = 0.20f, gridShift = 0, sha256 = "ref_washbasin_01")
        val liveSlightShift = createMockFingerprint(
            seedAngle = 0.24f,
            gridShift = 1,
            sha256 = "live_washbasin_02",
            lumMean = 0.41f
        )

        val result = engine.verify(ref, liveSlightShift, MatchingDifficulty.NORMAL)
        assertTrue("Slightly shifted live capture of same scene should match (score=${result.overallScore})", result.isMatched)
        assertTrue(result.overallScore >= MatchingDifficulty.NORMAL.defaultThreshold)
    }

    @Test
    fun `completely different scene is rejected`() {
        val refWashbasin = createMockFingerprint(seedAngle = 0.20f, gridShift = 0, sha256 = "ref_washbasin")
        val liveRefrigerator = createMockFingerprint(seedAngle = 2.85f, gridShift = 45, sha256 = "live_fridge")

        val result = engine.verify(refWashbasin, liveRefrigerator, MatchingDifficulty.NORMAL)
        assertFalse("Unrelated scene must be rejected (score=${result.overallScore})", result.isMatched)
    }

    @Test
    fun `pitch black or covered camera lens is rejected`() {
        val ref = createMockFingerprint(seedAngle = 0.20f, sha256 = "ref_1")
        val darkFrame = createMockFingerprint(seedAngle = 0.20f, sha256 = "live_dark", lumMean = 0.01f)

        val result = engine.verify(ref, darkFrame, MatchingDifficulty.EASY)
        assertFalse(result.isMatched)
        assertFalse(result.livenessPassed)
    }
}
